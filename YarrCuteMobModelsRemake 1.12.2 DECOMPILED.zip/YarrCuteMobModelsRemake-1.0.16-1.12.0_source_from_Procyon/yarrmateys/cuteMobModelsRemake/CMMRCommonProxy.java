// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake;

public class CMMRCommonProxy
{
    public void registerRenderThings() {
    }
    
    public void registerSoundHandler() {
    }
}
