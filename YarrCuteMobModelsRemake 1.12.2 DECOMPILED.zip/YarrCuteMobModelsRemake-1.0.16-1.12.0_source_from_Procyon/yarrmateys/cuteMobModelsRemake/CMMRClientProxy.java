// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake;

import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class CMMRClientProxy extends CMMRCommonProxy
{
    public static void preInit() {
    }
    
    public static void init() {
    }
    
    public static void postInit() {
    }
}
