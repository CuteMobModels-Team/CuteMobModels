// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake;

import net.minecraft.entity.monster.EntityZombieVillager;
import net.minecraft.entity.monster.EntityHusk;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.entity.monster.EntityWitch;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.entity.monster.EntityStray;
import net.minecraft.entity.monster.EntityWitherSkeleton;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.entity.passive.EntityMooshroom;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.entity.monster.EntitySpider;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.entity.monster.EntityMagmaCube;
import net.minecraft.entity.monster.EntityElderGuardian;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.entity.monster.EntityGhast;
import net.minecraft.entity.monster.EntityEnderman;
import net.minecraft.entity.monster.EntityCaveSpider;
import net.minecraft.entity.monster.EntityBlaze;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRMooshroom;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRMooshroom;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRMooshroom;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRHusk;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRHusk;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRZombieVillager;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRZombieVillager;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRZombieVillager;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRZombie;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRZombie;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRZombie;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRWolf;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRWolf;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRWolf;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRWitch;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRWitch;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRWitch;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRVillager;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRVillager;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRVillager;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRIronGolem;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRIronGolem;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRIronGolem;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRSpider;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRSpider;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSpider;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRSnowGolem;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRSnowGolem;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSnowman;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRSlime;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRSlime;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSlime;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRStray;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRStray;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRWitherSkeleton;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRWitherSkeleton;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRSkeleton;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRSkeleton;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSkeleton;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRSilverfish;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRSilverfish;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSilverfish;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRPigZombie;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRPigZombie;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRPigZombie;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRMagmaCube;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRMagmaCube;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRMagmaCube;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRElderGuardian;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRElderGuardian;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRElderGuardian;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRGuardian;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRGuardian;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRGuardian;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRGhast;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRGhast;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRGhast;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMREnderman;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMREnderman;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMREnderman;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRCaveSpider;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRCaveSpider;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRCaveSpider;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRCreeper;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRCreeper;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRCreeper;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRBlaze;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRBlaze;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRBlaze;
import net.minecraft.client.renderer.entity.Render;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRGhastS;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRGhastS;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRGhastS;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class CMMRRenderer
{
    public static void preInit() {
    }
    
    public static void init() {
        RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRGhastS.class, (Render)new RenderCMMRGhastS(new ModelCMMRGhastS(0.0f, 0.0f), 0.3f));
        if (YarrCuteMobModelsRemake.enableMod) {
            if (YarrCuteMobModelsRemake.separateEntities) {
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRBlaze.class, (Render)new RenderCMMRBlaze(new ModelCMMRBlaze(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRCreeper.class, (Render)new RenderCMMRCreeper(new ModelCMMRCreeper(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRCaveSpider.class, (Render)new RenderCMMRCaveSpider(new ModelCMMRCaveSpider(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMREnderman.class, (Render)new RenderCMMREnderman(new ModelCMMREnderman(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRGhast.class, (Render)new RenderCMMRGhast(new ModelCMMRGhast(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRGuardian.class, (Render)new RenderCMMRGuardian(new ModelCMMRGuardian(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRElderGuardian.class, (Render)new RenderCMMRElderGuardian(new ModelCMMRElderGuardian(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRMagmaCube.class, (Render)new RenderCMMRMagmaCube(new ModelCMMRMagmaCube(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRPigZombie.class, (Render)new RenderCMMRPigZombie(new ModelCMMRPigZombie(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRSilverfish.class, (Render)new RenderCMMRSilverfish(new ModelCMMRSilverfish(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRSkeleton.class, (Render)new RenderCMMRSkeleton(new ModelCMMRSkeleton(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRWitherSkeleton.class, (Render)new RenderCMMRWitherSkeleton(new ModelCMMRSkeleton(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRStray.class, (Render)new RenderCMMRStray(new ModelCMMRSkeleton(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRSlime.class, (Render)new RenderCMMRSlime(new ModelCMMRSlime(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRSnowman.class, (Render)new RenderCMMRSnowGolem(new ModelCMMRSnowGolem(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRSpider.class, (Render)new RenderCMMRSpider(new ModelCMMRSpider(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRIronGolem.class, (Render)new RenderCMMRIronGolem(new ModelCMMRIronGolem(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRVillager.class, (Render)new RenderCMMRVillager(new ModelCMMRVillager(0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRWitch.class, (Render)new RenderCMMRWitch(new ModelCMMRWitch(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRWolf.class, (Render)new RenderCMMRWolf(new ModelCMMRWolf(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRZombie.class, (Render)new RenderCMMRZombie(new ModelCMMRZombie(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRZombieVillager.class, (Render)new RenderCMMRZombieVillager(new ModelCMMRZombieVillager(0.0f, 0.0f), 0.3f));
                RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRHusk.class, (Render)new RenderCMMRHusk(new ModelCMMRZombie(0.0f, 0.0f), 0.3f));
                if (YarrCuteMobModelsRemake.replaceAnimals && YarrCuteMobModelsRemake.MooshroomReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityCMMRMooshroom.class, (Render)new RenderCMMRMooshroom(new ModelCMMRMooshroom(0.0f, 0.0f), 0.3f));
                }
            }
            if (!YarrCuteMobModelsRemake.separateEntities) {
                if (YarrCuteMobModelsRemake.BlazeReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityBlaze.class, (Render)new RenderCMMRBlaze(new ModelCMMRBlaze(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.CaveSpiderReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityCaveSpider.class, (Render)new RenderCMMRCaveSpider(new ModelCMMRCaveSpider(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.EndermanReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityEnderman.class, (Render)new RenderCMMREnderman(new ModelCMMREnderman(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.GhastReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityGhast.class, (Render)new RenderCMMRGhast(new ModelCMMRGhast(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.GuardianReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityGuardian.class, (Render)new RenderCMMRGuardian(new ModelCMMRGuardian(0.0f, 0.0f), 0.3f));
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityElderGuardian.class, (Render)new RenderCMMRElderGuardian(new ModelCMMRElderGuardian(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.MagmaCubeReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityMagmaCube.class, (Render)new RenderCMMRMagmaCube(new ModelCMMRMagmaCube(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.SilverfishReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntitySilverfish.class, (Render)new RenderCMMRSilverfish(new ModelCMMRSilverfish(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.SlimeReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntitySlime.class, (Render)new RenderCMMRSlime(new ModelCMMRSlime(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.SpiderReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntitySpider.class, (Render)new RenderCMMRSpider(new ModelCMMRSpider(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.IronGolemReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityIronGolem.class, (Render)new RenderCMMRIronGolem(new ModelCMMRIronGolem(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.replaceAnimals && YarrCuteMobModelsRemake.MooshroomReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityMooshroom.class, (Render)new RenderCMMRMooshroom(new ModelCMMRMooshroom(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.CreeperReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityCreeper.class, (Render)new RenderCMMRCreeper(new ModelCMMRCreeper(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.PigZombieReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityPigZombie.class, (Render)new RenderCMMRPigZombie(new ModelCMMRPigZombie(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.SkeletonReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntitySkeleton.class, (Render)new RenderCMMRSkeleton(new ModelCMMRSkeleton(0.0f, 0.0f), 0.3f));
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityWitherSkeleton.class, (Render)new RenderCMMRWitherSkeleton(new ModelCMMRSkeleton(0.0f, 0.0f), 0.3f));
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityStray.class, (Render)new RenderCMMRStray(new ModelCMMRSkeleton(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.SnowGolemReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntitySnowman.class, (Render)new RenderCMMRSnowGolem(new ModelCMMRSnowGolem(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.VillagerReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityVillager.class, (Render)new RenderCMMRVillager(new ModelCMMRVillager(0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.WitchReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityWitch.class, (Render)new RenderCMMRWitch(new ModelCMMRWitch(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.WolfReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityWolf.class, (Render)new RenderCMMRWolf(new ModelCMMRWolf(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.ZombieReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityZombie.class, (Render)new RenderCMMRZombie(new ModelCMMRZombie(0.0f, 0.0f), 0.3f));
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityHusk.class, (Render)new RenderCMMRHusk(new ModelCMMRZombie(0.0f, 0.0f), 0.3f));
                }
                if (YarrCuteMobModelsRemake.ZombieVillagerReplaceModel) {
                    RenderingRegistry.registerEntityRenderingHandler((Class)EntityZombieVillager.class, (Render)new RenderCMMRZombieVillager(new ModelCMMRZombieVillager(0.0f, 0.0f), 0.3f));
                }
            }
        }
    }
}
