// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMRSkeletonHeldItem;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.entity.monster.EntitySkeleton;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRSkeleton extends RenderLiving<EntitySkeleton>
{
    private static final ResourceLocation SKELETON;
    private static final ResourceLocation WITHER_SKELETON;
    private static final ResourceLocation STRAY_SKELETON;
    private static final ResourceLocation SKELETON_BL;
    private static final ResourceLocation WITHER_SKELETON_BL;
    private static final ResourceLocation STRAY_SKELETON_BL;
    protected ModelCMMRSkeleton ModelCMMRSkeletonMain;
    protected float field_40296_d;
    
    public RenderCMMRSkeleton(final ModelCMMRSkeleton modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
        this.func_177094_a((LayerRenderer)new LayerCMMRSkeletonHeldItem((RenderLivingBase)this));
    }
    
    protected ResourceLocation getEntityTexture(final EntitySkeleton entity) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMRSkeleton.SKELETON;
        }
        return RenderCMMRSkeleton.SKELETON_BL;
    }
    
    static {
        SKELETON = new ResourceLocation("yarrmateys_cutemobmodels:textures/Skeleton.png");
        WITHER_SKELETON = new ResourceLocation("yarrmateys_cutemobmodels:textures/SkeletonW.png");
        STRAY_SKELETON = new ResourceLocation("yarrmateys_cutemobmodels:textures/SkeletonS.png");
        SKELETON_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSkeleton.png");
        WITHER_SKELETON_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSkeletonW.png");
        STRAY_SKELETON_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSkeletonS.png");
    }
}
