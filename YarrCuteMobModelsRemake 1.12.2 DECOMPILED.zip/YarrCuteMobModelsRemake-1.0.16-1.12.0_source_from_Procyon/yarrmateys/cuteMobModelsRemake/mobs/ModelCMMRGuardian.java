// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.EnumHandSide;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.MathHelper;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.client.model.ModelRenderer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.model.ModelBase;

@SideOnly(Side.CLIENT)
public class ModelCMMRGuardian extends ModelBase
{
    ModelRenderer HTop;
    ModelRenderer Hair;
    ModelRenderer Head;
    ModelRenderer RHorn;
    ModelRenderer LHorn;
    ModelRenderer REar;
    ModelRenderer LEar;
    ModelRenderer Neck;
    ModelRenderer RArm;
    ModelRenderer LArm;
    ModelRenderer Body;
    ModelRenderer BustTop;
    ModelRenderer BustFront;
    ModelRenderer BustBottom;
    ModelRenderer Body2;
    ModelRenderer[] Tail;
    ModelRenderer Tail1;
    ModelRenderer Tail2;
    ModelRenderer Tail3;
    ModelRenderer Tail4;
    ModelRenderer Skirt1;
    ModelRenderer Skirt2;
    ModelRenderer RLeg;
    ModelRenderer LLeg;
    public ModelRenderer bypedHead;
    public ModelRenderer bypedBody;
    public ModelRenderer bypedRightArm;
    public ModelRenderer bypedLeftArm;
    public ModelRenderer bypedRightLeg;
    public ModelRenderer bypedLeftLeg;
    public ModelRenderer bypedHeadwear;
    public ModelRenderer bypedBodyWear;
    public ModelRenderer bypedLeftArmwear;
    public ModelRenderer bypedRightArmwear;
    public ModelRenderer bypedLeftLegwear;
    public ModelRenderer bypedRightLegwear;
    public ModelRenderer bypedCape;
    public ModelRenderer[] bypedTail;
    public int heldItemLeft;
    public int heldItemRight;
    public boolean isOnLadder;
    public boolean onGround;
    public boolean inWater;
    public boolean inWater2;
    public boolean isSneak;
    public boolean aimedBow;
    private int textureWidthbyped;
    private int textureHeightbyped;
    
    public ModelCMMRGuardian(final float modelSize, final float offset) {
        this.field_78090_t = 64;
        this.field_78089_u = 64;
        (this.HTop = new ModelRenderer((ModelBase)this, 0, 28)).func_78789_a(-3.5f, -8.0f, -3.0f, 7, 1, 6);
        this.HTop.func_78793_a(0.0f, 0.0f, 0.0f);
        this.HTop.func_78787_b(64, 64);
        this.HTop.field_78809_i = true;
        this.setRotation(this.HTop, 0.0f, 0.0f, 0.0f);
        (this.Hair = new ModelRenderer((ModelBase)this, 0, 13)).func_78789_a(-4.0f, -7.0f, -3.5f, 8, 8, 7);
        this.Hair.func_78793_a(0.0f, 0.0f, 0.0f);
        this.Hair.func_78787_b(64, 64);
        this.Hair.field_78809_i = true;
        this.setRotation(this.Hair, 0.0f, 0.0f, 0.0f);
        (this.Head = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(-3.5f, -7.0f, -3.0f, 7, 7, 6);
        this.Head.func_78793_a(0.0f, 0.0f, 0.0f);
        this.Head.func_78787_b(64, 64);
        this.Head.field_78809_i = true;
        this.setRotation(this.Head, 0.0f, 0.0f, 0.0f);
        (this.RHorn = new ModelRenderer((ModelBase)this, 0, 37)).func_78789_a(-5.0f, -7.5f, -1.0f, 2, 1, 1);
        this.RHorn.func_78793_a(0.0f, 0.0f, 0.0f);
        this.RHorn.func_78787_b(64, 64);
        this.RHorn.field_78809_i = true;
        (this.LHorn = new ModelRenderer((ModelBase)this, 0, 35)).func_78789_a(3.0f, -7.5f, -1.0f, 2, 1, 1);
        this.LHorn.func_78793_a(0.0f, 0.0f, 0.0f);
        this.LHorn.func_78787_b(64, 64);
        this.LHorn.field_78809_i = true;
        (this.REar = new ModelRenderer((ModelBase)this, 18, 56)).func_78789_a(-5.5f, -4.0f, -1.5f, 2, 3, 1);
        this.REar.func_78793_a(0.0f, 0.0f, 0.0f);
        this.REar.func_78787_b(64, 64);
        this.REar.field_78809_i = true;
        this.setRotation(this.REar, 0.0f, 0.0f, 0.0f);
        (this.LEar = new ModelRenderer((ModelBase)this, 18, 60)).func_78789_a(3.5f, -4.0f, -1.5f, 2, 3, 1);
        this.LEar.func_78793_a(0.0f, 0.0f, 0.0f);
        this.LEar.func_78787_b(64, 64);
        this.LEar.field_78809_i = true;
        this.setRotation(this.LEar, 0.0f, 0.0f, 0.0f);
        (this.Neck = new ModelRenderer((ModelBase)this, 52, 47)).func_78789_a(-1.5f, -0.5f, -1.5f, 3, 2, 3);
        this.Neck.func_78793_a(0.0f, 0.0f, 0.0f);
        this.Neck.func_78787_b(64, 64);
        this.Neck.field_78809_i = true;
        this.setRotation(this.Neck, 0.0f, 0.0f, 0.0f);
        (this.RArm = new ModelRenderer((ModelBase)this, 56, 15)).func_78789_a(-2.0f, -1.0f, -1.0f, 2, 12, 2);
        this.RArm.func_78793_a(-3.5f, 2.0f, 0.0f);
        this.RArm.func_78787_b(64, 64);
        this.RArm.field_78809_i = true;
        this.setRotation(this.RArm, 0.0f, 0.0f, 0.0f);
        (this.LArm = new ModelRenderer((ModelBase)this, 32, 0)).func_78789_a(0.0f, -1.0f, -1.0f, 2, 12, 2);
        this.LArm.func_78793_a(3.5f, 2.0f, 0.0f);
        this.LArm.func_78787_b(64, 64);
        this.LArm.field_78809_i = true;
        this.setRotation(this.LArm, 0.0f, 0.0f, 0.0f);
        (this.Body = new ModelRenderer((ModelBase)this, 0, 47)).func_78789_a(-3.5f, 0.0f, -1.5f, 7, 5, 3);
        this.Body.func_78793_a(0.0f, 1.0f, 0.0f);
        this.Body.func_78787_b(64, 64);
        this.Body.field_78809_i = true;
        this.setRotation(this.Body, 0.0f, 0.0f, 0.0f);
        (this.BustTop = new ModelRenderer((ModelBase)this, 48, 52)).func_78789_a(-3.0f, 0.0f, 0.0f, 6, 2, 2);
        this.BustTop.func_78793_a(0.0f, 1.9f, -1.5f);
        this.BustTop.func_78787_b(64, 64);
        this.BustTop.field_78809_i = true;
        this.setRotation(this.BustTop, -0.7853982f, 0.0f, 0.0f);
        (this.BustFront = new ModelRenderer((ModelBase)this, 48, 56)).func_78789_a(-3.0f, 3.3f, -2.9f, 6, 2, 2);
        this.BustFront.func_78793_a(0.0f, 0.0f, 0.0f);
        this.BustFront.func_78787_b(64, 64);
        this.BustFront.field_78809_i = true;
        this.setRotation(this.BustFront, 0.0f, 0.0f, 0.0f);
        (this.BustBottom = new ModelRenderer((ModelBase)this, 48, 60)).func_78789_a(-3.0f, 0.0f, 0.0f, 6, 2, 2);
        this.BustBottom.func_78793_a(0.0f, 3.5f, -2.0f);
        this.BustBottom.func_78787_b(64, 64);
        this.BustBottom.field_78809_i = true;
        this.setRotation(this.BustBottom, -0.4363323f, 0.0f, 0.0f);
        (this.Body2 = new ModelRenderer((ModelBase)this, 0, 55)).func_78789_a(-3.0f, 6.0f, -1.5f, 6, 6, 3);
        this.Body2.func_78793_a(0.0f, 0.0f, 0.0f);
        this.Body2.func_78787_b(64, 64);
        this.Body2.field_78809_i = true;
        this.setRotation(this.Body2, 0.0f, 0.0f, 0.0f);
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            this.Tail = new ModelRenderer[3];
            (this.Tail[0] = new ModelRenderer((ModelBase)this, 32, 15)).func_78789_a(-2.0f, -2.0f, 0.0f, 4, 4, 8);
            (this.Tail[1] = new ModelRenderer((ModelBase)this, 18, 36)).func_78789_a(-1.5f, -1.5f, 0.0f, 3, 3, 7);
            this.Tail[2] = new ModelRenderer((ModelBase)this);
            this.Tail[2].func_78784_a(0, 39).func_78789_a(-1.0f, -1.0f, 0.0f, 2, 2, 6);
            this.Tail[2].func_78784_a(28, 46).func_78789_a(0.0f, -4.5f, 5.5f, 1, 9, 9);
            this.Body2.func_78792_a(this.Tail[0]);
            this.Tail[0].func_78792_a(this.Tail[1]);
            this.Tail[1].func_78792_a(this.Tail[2]);
        }
        (this.Skirt1 = new ModelRenderer((ModelBase)this, 42, 29)).func_78789_a(-3.5f, 0.0f, -2.0f, 7, 4, 4);
        this.Skirt1.func_78793_a(0.0f, 9.0f, 0.0f);
        this.Skirt1.func_78787_b(64, 64);
        this.Skirt1.field_78809_i = true;
        this.setRotation(this.Skirt1, 0.0f, 0.0f, 0.0f);
        (this.Skirt2 = new ModelRenderer((ModelBase)this, 38, 37)).func_78789_a(-4.0f, 3.0f, -2.5f, 8, 4, 5);
        this.Skirt2.func_78793_a(0.0f, 9.0f, 0.0f);
        this.Skirt2.func_78787_b(64, 64);
        this.Skirt2.field_78809_i = true;
        this.setRotation(this.Skirt2, 0.0f, 0.0f, 0.0f);
        (this.RLeg = new ModelRenderer((ModelBase)this, 52, 0)).func_78789_a(-1.5f, 0.0f, -1.5f, 3, 12, 3);
        this.RLeg.func_78793_a(-2.0f, 12.0f, 0.0f);
        this.RLeg.func_78787_b(64, 64);
        this.RLeg.field_78809_i = true;
        this.setRotation(this.RLeg, 0.0f, 0.0f, 0.0f);
        (this.LLeg = new ModelRenderer((ModelBase)this, 40, 0)).func_78789_a(-1.5f, 0.0f, -1.5f, 3, 12, 3);
        this.LLeg.func_78793_a(2.0f, 12.0f, 0.0f);
        this.LLeg.func_78787_b(64, 64);
        this.LLeg.field_78809_i = true;
        this.setRotation(this.LLeg, 0.0f, 0.0f, 0.0f);
        this.textureWidthbyped = 64;
        this.textureHeightbyped = 64;
        (this.bypedHead = new ModelRenderer((ModelBase)this, 0, 0)).func_78790_a(-4.0f, -8.0f, -4.0f, 8, 8, 8, modelSize);
        this.bypedHead.func_78793_a(0.0f, 0.0f + offset, 0.0f);
        this.bypedHead.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedBody = new ModelRenderer((ModelBase)this, 16, 16)).func_78790_a(-4.0f, 0.0f, -2.0f, 8, 12, 4, modelSize);
        this.bypedBody.func_78793_a(0.0f, 0.0f + offset, 0.0f);
        this.bypedBody.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedRightArm = new ModelRenderer((ModelBase)this, 40, 16)).func_78790_a(-3.0f, -2.0f, -2.0f, 4, 12, 4, modelSize);
        this.bypedRightArm.func_78793_a(-5.0f, 2.0f + offset, 0.0f);
        this.bypedRightArm.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedLeftArm = new ModelRenderer((ModelBase)this, 32, 48)).func_78790_a(-1.0f, -2.0f, -2.0f, 4, 12, 4, modelSize);
        this.bypedLeftArm.func_78793_a(5.0f, 2.0f + offset, 0.0f);
        this.bypedLeftArm.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedRightLeg = new ModelRenderer((ModelBase)this, 0, 16)).func_78790_a(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize);
        this.bypedRightLeg.func_78793_a(-1.9f, 12.0f + offset, 0.0f);
        this.bypedRightLeg.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedLeftLeg = new ModelRenderer((ModelBase)this, 16, 48)).func_78790_a(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize);
        this.bypedLeftLeg.func_78793_a(1.9f, 12.0f + offset, 0.0f);
        this.bypedLeftLeg.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedHeadwear = new ModelRenderer((ModelBase)this, 32, 0)).func_78790_a(-4.0f, -8.0f, -4.0f, 8, 8, 8, modelSize + 0.5f);
        this.bypedHeadwear.func_78793_a(0.0f, 0.0f + offset, 0.0f);
        this.bypedHeadwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedBodyWear = new ModelRenderer((ModelBase)this, 16, 32)).func_78790_a(-4.0f, 0.0f, -2.0f, 8, 12, 4, modelSize + 0.25f);
        this.bypedBodyWear.func_78793_a(0.0f, 0.0f, 0.0f);
        this.bypedBodyWear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedLeftArmwear = new ModelRenderer((ModelBase)this, 48, 48)).func_78790_a(-1.0f, -2.0f, -2.0f, 4, 12, 4, modelSize + 0.25f);
        this.bypedLeftArmwear.func_78793_a(5.0f, 2.0f, 0.0f);
        this.bypedLeftArmwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedRightArmwear = new ModelRenderer((ModelBase)this, 40, 32)).func_78790_a(-3.0f, -2.0f, -2.0f, 4, 12, 4, modelSize + 0.25f);
        this.bypedRightArmwear.func_78793_a(-5.0f, 2.0f, 10.0f);
        this.bypedRightArmwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedLeftLegwear = new ModelRenderer((ModelBase)this, 0, 48)).func_78790_a(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize + 0.25f);
        this.bypedLeftLegwear.func_78793_a(1.9f, 12.0f, 0.0f);
        this.bypedLeftLegwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedRightLegwear = new ModelRenderer((ModelBase)this, 0, 32)).func_78790_a(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize + 0.25f);
        this.bypedRightLegwear.func_78793_a(-1.9f, 12.0f, 0.0f);
        this.bypedRightLegwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        if (YarrCuteMobModelsRemake.humanMobsModels) {
            this.Tail = new ModelRenderer[3];
            (this.Tail[0] = new ModelRenderer((ModelBase)this, 0, 32)).func_78789_a(-2.0f, -2.0f, 0.0f, 4, 4, 8);
            (this.Tail[1] = new ModelRenderer((ModelBase)this, 24, 32)).func_78789_a(-1.5f, -1.5f, 0.0f, 3, 3, 7);
            this.Tail[2] = new ModelRenderer((ModelBase)this);
            this.Tail[2].func_78784_a(0, 56).func_78789_a(-1.0f, -1.0f, 0.0f, 2, 2, 6);
            this.Tail[2].func_78784_a(44, 32).func_78789_a(0.0f, -4.5f, 5.5f, 1, 9, 9);
            this.bypedBody.func_78792_a(this.Tail[0]);
            this.Tail[0].func_78792_a(this.Tail[1]);
            this.Tail[1].func_78792_a(this.Tail[2]);
        }
    }
    
    public int func_178706_a() {
        return 54;
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78087_a(final float par1, final float par2, final float par3, final float par4, final float par5, final float par6, final Entity par7Entity) {
        super.func_78087_a(par1, par2, par3, par4, par5, par6, par7Entity);
        final EntityGuardian entityguardian = (EntityGuardian)par7Entity;
        final float f6 = par3 - entityguardian.field_70173_aa;
        this.BustTop.field_78807_k = true;
        this.BustFront.field_78807_k = true;
        this.BustBottom.field_78807_k = true;
        final float f7 = entityguardian.func_175471_a(f6);
        this.Tail[0].field_78796_g = MathHelper.func_76126_a(f7) * 3.1415927f * 0.05f;
        this.Tail[0].field_78800_c = 0.0f;
        this.Tail[0].field_78797_d = 10.0f;
        this.Tail[0].field_78798_e = 1.0f;
        this.Tail[1].field_78796_g = MathHelper.func_76126_a(f7) * 3.1415927f * 0.1f;
        this.Tail[1].field_78800_c = 0.0f;
        this.Tail[1].field_78797_d = 0.0f;
        this.Tail[1].field_78798_e = 7.0f;
        this.Tail[2].field_78796_g = MathHelper.func_76126_a(f7) * 3.1415927f * 0.15f;
        this.Tail[2].field_78800_c = 0.0f;
        this.Tail[2].field_78797_d = 0.0f;
        this.Tail[2].field_78798_e = 6.0f;
        this.Body.field_78795_f = 0.0f;
        this.Body2.field_78795_f = 0.0f;
        this.Head.field_78796_g = par4 / 57.295776f;
        this.Head.field_78795_f = par5 / 57.295776f;
        this.HTop.field_78796_g = this.Head.field_78796_g;
        this.HTop.field_78795_f = this.Head.field_78795_f;
        this.Hair.field_78796_g = this.Head.field_78796_g;
        this.Hair.field_78795_f = this.Head.field_78795_f;
        this.RHorn.field_78808_h = this.Head.field_78808_h;
        this.RHorn.field_78796_g = this.Head.field_78796_g;
        this.RHorn.field_78795_f = this.Head.field_78795_f;
        this.LHorn.field_78808_h = this.Head.field_78808_h;
        this.LHorn.field_78796_g = this.Head.field_78796_g;
        this.LHorn.field_78795_f = this.Head.field_78795_f;
        this.REar.field_78796_g = this.Head.field_78796_g;
        this.REar.field_78795_f = this.Head.field_78795_f;
        this.LEar.field_78796_g = this.Head.field_78796_g;
        this.LEar.field_78795_f = this.Head.field_78795_f;
        if (par7Entity.func_70090_H()) {
            this.RArm.field_78795_f = 0.2f * MathHelper.func_76126_a(par3 * 0.2f) + 0.15f;
            this.RArm.field_78808_h = 0.08f * MathHelper.func_76126_a(par3 * 0.2f) + 0.35f;
            this.LArm.field_78795_f = 0.2f * MathHelper.func_76126_a(par3 * 0.2f) + 0.15f;
            this.LArm.field_78808_h = -0.08f * MathHelper.func_76126_a(par3 * 0.2f) - 0.35f;
            this.RLeg.field_78795_f = 0.25f * MathHelper.func_76126_a(par3 * 0.2f) + 0.3f;
            this.LLeg.field_78795_f = 0.25f * MathHelper.func_76126_a(par3 * 0.2f) + 0.3f;
            this.Skirt1.field_78795_f = 0.06f * MathHelper.func_76126_a(par3 * 0.2f) + 0.1f;
            this.Skirt2.field_78795_f = 0.1f * MathHelper.func_76126_a(par3 * 0.2f) + 0.2f;
        }
        else if (this.field_78093_q) {
            this.RArm.field_78796_g = 0.0f;
            this.LArm.field_78796_g = 0.0f;
            this.RArm.field_78808_h = 0.1f * MathHelper.func_76126_a(par3 * 0.1f) + 0.1f;
            this.LArm.field_78808_h = -0.1f * MathHelper.func_76126_a(par3 * 0.1f) - 0.1f;
            final ModelRenderer rArm = this.RArm;
            rArm.field_78795_f -= 0.62831855f;
            final ModelRenderer lArm = this.LArm;
            lArm.field_78795_f -= 0.62831855f;
            this.RLeg.field_78795_f = -1.2566371f;
            this.LLeg.field_78795_f = -1.2566371f;
            this.RLeg.field_78796_g = 0.31415927f;
            this.LLeg.field_78796_g = -0.31415927f;
            this.Skirt2.field_78795_f = this.RLeg.field_78795_f;
            this.Skirt2.field_78796_g = 0.0f;
        }
        else {
            final float varX = -2.317994f;
            final float varY = 0.617994f;
            this.RArm.field_78795_f = varX;
            this.LArm.field_78795_f = varX;
            this.RArm.field_78796_g = varY;
            this.LArm.field_78796_g = -varY;
            this.RArm.field_78808_h = 0.1f * MathHelper.func_76126_a(par3 * 0.1f) + 0.1f;
            this.LArm.field_78808_h = -0.1f * MathHelper.func_76126_a(par3 * 0.1f) - 0.1f;
            this.RLeg.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f) * 1.4f * par2;
            this.LLeg.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f + 3.1415927f) * 1.4f * par2;
            this.RLeg.field_78796_g = 0.0f;
            this.LLeg.field_78796_g = 0.0f;
            this.Skirt1.field_78795_f = 0.0f;
            this.Skirt2.field_78795_f = 0.0f;
        }
        this.bypedHead.field_78796_g = par4 / 57.295776f;
        this.bypedHead.field_78795_f = par5 / 57.295776f;
        this.bypedRightArm.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f + 3.1415927f) * 2.0f * par2 * 0.5f;
        this.bypedLeftArm.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f) * 2.0f * par2 * 0.5f;
        this.bypedRightArm.field_78808_h = 0.0f;
        this.bypedLeftArm.field_78808_h = 0.0f;
        this.bypedRightLeg.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f) * 1.4f * par2;
        this.bypedLeftLeg.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f + 3.1415927f) * 1.4f * par2;
        this.bypedRightLeg.field_78796_g = 0.0f;
        this.bypedLeftLeg.field_78796_g = 0.0f;
        if (this.field_78093_q) {
            final ModelRenderer bypedRightArm = this.bypedRightArm;
            bypedRightArm.field_78795_f -= 0.62831855f;
            final ModelRenderer bypedLeftArm = this.bypedLeftArm;
            bypedLeftArm.field_78795_f -= 0.62831855f;
            this.bypedRightLeg.field_78795_f = -1.2566371f;
            this.bypedLeftLeg.field_78795_f = -1.2566371f;
            this.bypedRightLeg.field_78796_g = 0.31415927f;
            this.bypedLeftLeg.field_78796_g = -0.31415927f;
        }
        if (this.heldItemLeft != 0) {
            this.bypedLeftArm.field_78795_f = this.bypedLeftArm.field_78795_f * 0.5f - 0.31415927f * this.heldItemLeft;
        }
        this.bypedRightArm.field_78796_g = 0.0f;
        this.bypedRightArm.field_78808_h = 0.0f;
        switch (this.heldItemRight) {
            case 1: {
                this.bypedRightArm.field_78795_f = this.bypedRightArm.field_78795_f * 0.5f - 0.31415927f * this.heldItemRight;
                break;
            }
            case 3: {
                this.bypedRightArm.field_78795_f = this.bypedRightArm.field_78795_f * 0.5f - 0.31415927f * this.heldItemRight;
                this.bypedRightArm.field_78796_g = -0.5235988f;
                break;
            }
        }
        this.bypedLeftArm.field_78796_g = 0.0f;
        if (this.field_78095_p > -9990.0f) {
            float f8 = this.field_78095_p;
            this.bypedBody.field_78796_g = MathHelper.func_76126_a(MathHelper.func_76129_c(f8) * 3.1415927f * 2.0f) * 0.2f;
            this.bypedRightArm.field_78798_e = MathHelper.func_76126_a(this.bypedBody.field_78796_g) * 5.0f;
            this.bypedRightArm.field_78800_c = -MathHelper.func_76134_b(this.bypedBody.field_78796_g) * 5.0f;
            this.bypedLeftArm.field_78798_e = -MathHelper.func_76126_a(this.bypedBody.field_78796_g) * 5.0f;
            this.bypedLeftArm.field_78800_c = MathHelper.func_76134_b(this.bypedBody.field_78796_g) * 5.0f;
            final ModelRenderer bypedRightArm2 = this.bypedRightArm;
            bypedRightArm2.field_78796_g += this.bypedBody.field_78796_g;
            final ModelRenderer bypedLeftArm2 = this.bypedLeftArm;
            bypedLeftArm2.field_78796_g += this.bypedBody.field_78796_g;
            final ModelRenderer bypedLeftArm3 = this.bypedLeftArm;
            bypedLeftArm3.field_78795_f += this.bypedBody.field_78796_g;
            f8 = 1.0f - this.field_78095_p;
            f8 *= f8;
            f8 *= f8;
            f8 = 1.0f - f8;
            final float f9 = MathHelper.func_76126_a(f8 * 3.1415927f);
            final float f10 = MathHelper.func_76126_a(this.field_78095_p * 3.1415927f) * -(this.bypedHead.field_78795_f - 0.7f) * 0.75f;
            this.bypedRightArm.field_78795_f -= (float)(f9 * 1.2 + f10);
            final ModelRenderer bypedRightArm3 = this.bypedRightArm;
            bypedRightArm3.field_78796_g += this.bypedBody.field_78796_g * 2.0f;
            final ModelRenderer bypedRightArm4 = this.bypedRightArm;
            bypedRightArm4.field_78808_h += MathHelper.func_76126_a(this.field_78095_p * 3.1415927f) * -0.4f;
        }
        if (this.isSneak) {
            this.bypedBody.field_78795_f = 0.5f;
            final ModelRenderer bypedRightArm5 = this.bypedRightArm;
            bypedRightArm5.field_78795_f += 0.4f;
            final ModelRenderer bypedLeftArm4 = this.bypedLeftArm;
            bypedLeftArm4.field_78795_f += 0.4f;
            this.bypedRightLeg.field_78798_e = 4.0f;
            this.bypedLeftLeg.field_78798_e = 4.0f;
            this.bypedRightLeg.field_78797_d = 9.0f;
            this.bypedLeftLeg.field_78797_d = 9.0f;
            this.bypedHead.field_78797_d = 1.0f;
        }
        else {
            this.bypedBody.field_78795_f = 0.0f;
            this.bypedRightLeg.field_78798_e = 0.1f;
            this.bypedLeftLeg.field_78798_e = 0.1f;
            this.bypedRightLeg.field_78797_d = 12.0f;
            this.bypedLeftLeg.field_78797_d = 12.0f;
            this.bypedHead.field_78797_d = 0.0f;
        }
        final ModelRenderer bypedRightArm6 = this.bypedRightArm;
        bypedRightArm6.field_78808_h += MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer bypedLeftArm5 = this.bypedLeftArm;
        bypedLeftArm5.field_78808_h -= MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer bypedRightArm7 = this.bypedRightArm;
        bypedRightArm7.field_78795_f += MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        final ModelRenderer bypedLeftArm6 = this.bypedLeftArm;
        bypedLeftArm6.field_78795_f -= MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        if (this.aimedBow) {
            final float f11 = 0.0f;
            final float f12 = 0.0f;
            this.bypedRightArm.field_78808_h = 0.0f;
            this.bypedLeftArm.field_78808_h = 0.0f;
            this.bypedRightArm.field_78796_g = -(0.1f - f11 * 0.6f) + this.bypedHead.field_78796_g;
            this.bypedLeftArm.field_78796_g = 0.1f - f11 * 0.6f + this.bypedHead.field_78796_g + 0.4f;
            this.bypedRightArm.field_78795_f = -1.5707964f + this.bypedHead.field_78795_f;
            this.bypedLeftArm.field_78795_f = -1.5707964f + this.bypedHead.field_78795_f;
            final ModelRenderer bypedRightArm8 = this.bypedRightArm;
            bypedRightArm8.field_78795_f -= f11 * 1.2f - f12 * 0.4f;
            final ModelRenderer bypedLeftArm7 = this.bypedLeftArm;
            bypedLeftArm7.field_78795_f -= f11 * 1.2f - f12 * 0.4f;
            final ModelRenderer bypedRightArm9 = this.bypedRightArm;
            bypedRightArm9.field_78808_h += MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
            final ModelRenderer bypedLeftArm8 = this.bypedLeftArm;
            bypedLeftArm8.field_78808_h -= MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
            final ModelRenderer bypedRightArm10 = this.bypedRightArm;
            bypedRightArm10.field_78795_f += MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
            final ModelRenderer bypedLeftArm9 = this.bypedLeftArm;
            bypedLeftArm9.field_78795_f -= MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        }
        func_178685_a(this.bypedHead, this.bypedHeadwear);
        func_178685_a(this.bypedBody, this.bypedBodyWear);
        func_178685_a(this.bypedRightArm, this.bypedRightArmwear);
        func_178685_a(this.bypedLeftArm, this.bypedLeftArmwear);
        func_178685_a(this.bypedRightLeg, this.bypedRightLegwear);
        func_178685_a(this.bypedLeftLeg, this.bypedLeftLegwear);
    }
    
    public void func_78088_a(final Entity par1Entity, final float par2, final float par3, final float par4, final float par5, final float par6, final float scale) {
        super.func_78088_a(par1Entity, par2, par3, par4, par5, par6, scale);
        this.func_78087_a(par2, par3, par4, par5, par6, scale, par1Entity);
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            this.HTop.func_78785_a(scale);
            this.Hair.func_78785_a(scale);
            this.Head.func_78785_a(scale);
            this.RHorn.func_78785_a(scale);
            this.LHorn.func_78785_a(scale);
            this.REar.func_78785_a(scale);
            this.LEar.func_78785_a(scale);
            this.Neck.func_78785_a(scale);
            this.RArm.func_78785_a(scale);
            this.LArm.func_78785_a(scale);
            this.Body.func_78785_a(scale);
            this.BustTop.func_78785_a(scale);
            this.BustFront.func_78785_a(scale);
            this.BustBottom.func_78785_a(scale);
            this.Body2.func_78785_a(scale);
            this.Skirt1.func_78785_a(scale);
            this.Skirt2.func_78785_a(scale);
            this.RLeg.func_78785_a(scale);
            this.LLeg.func_78785_a(scale);
        }
        else if (this.field_78091_s) {
            final float f1 = 1.5f;
            final float f2 = 2.0f;
            GlStateManager.func_179152_a(f1 / f2, f1 / f2, f1 / f2);
            GlStateManager.func_179109_b(0.0f, 8.0f * scale, 0.0f);
            this.bypedHead.func_78785_a(scale);
            this.bypedHeadwear.func_78785_a(scale);
            this.bypedBody.func_78785_a(scale);
            this.bypedRightArm.func_78785_a(scale);
            this.bypedLeftArm.func_78785_a(scale);
            this.bypedRightLeg.func_78785_a(scale);
            this.bypedLeftLeg.func_78785_a(scale);
        }
        else {
            if (par1Entity.func_70093_af()) {
                GlStateManager.func_179109_b(0.0f, 0.2f, 0.0f);
            }
            this.bypedHead.func_78785_a(scale);
            this.bypedHeadwear.func_78785_a(scale);
            this.bypedBody.func_78785_a(scale);
            this.bypedRightArm.func_78785_a(scale);
            this.bypedLeftArm.func_78785_a(scale);
            this.bypedRightLeg.func_78785_a(scale);
            this.bypedLeftLeg.func_78785_a(scale);
        }
    }
    
    public void postRenderArm(final float scale, final EnumHandSide side) {
        this.getArmForSide(side).func_78794_c(scale);
    }
    
    protected ModelRenderer getArmForSide(final EnumHandSide side) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return (side == EnumHandSide.LEFT) ? this.LArm : this.RArm;
        }
        return (side == EnumHandSide.LEFT) ? this.bypedLeftArm : this.bypedRightArm;
    }
    
    protected EnumHandSide getMainHand(final Entity par1) {
        return (par1 instanceof EntityLivingBase) ? ((EntityLivingBase)par1).func_184591_cq() : EnumHandSide.RIGHT;
    }
}
