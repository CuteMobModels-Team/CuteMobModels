// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.world.World;
import net.minecraft.entity.monster.EntityWitherSkeleton;

public class EntityCMMRWitherSkeleton extends EntityWitherSkeleton
{
    public EntityCMMRWitherSkeleton(final World var1) {
        super(var1);
    }
}
