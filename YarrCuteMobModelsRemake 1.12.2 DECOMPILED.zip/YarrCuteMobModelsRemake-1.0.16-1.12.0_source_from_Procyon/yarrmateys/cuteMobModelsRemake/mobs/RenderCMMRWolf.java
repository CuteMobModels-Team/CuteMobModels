// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.passive.EntityWolf;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMRWolfCollar;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRWolf extends RenderLiving
{
    private static final ResourceLocation wolfTextures;
    private static final ResourceLocation tamedWolfTextures;
    private static final ResourceLocation anrgyWolfTextures;
    private static final ResourceLocation wolfCollarTextures;
    private static final ResourceLocation wolfTexturesBl;
    private static final ResourceLocation tamedWolfTexturesBl;
    private static final ResourceLocation anrgyWolfTexturesBl;
    private static final ResourceLocation wolfCollarTexturesBl;
    private ModelCMMRWolf cuteModel;
    
    public RenderCMMRWolf(final ModelCMMRWolf modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
        this.func_177094_a((LayerRenderer)new LayerCMMRWolfCollar(this));
    }
    
    protected void preRenderWolf(final EntityWolf par1EntityWolf, final float par2) {
        float f1;
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            f1 = 0.9375f;
        }
        else {
            f1 = 0.5f;
        }
        if (par1EntityWolf.func_70874_b() < 0) {
            f1 *= 0.5;
            this.field_76989_e = 0.25f;
        }
        else {
            this.field_76989_e = 0.5f;
        }
        GlStateManager.func_179152_a(f1, f1, f1);
    }
    
    protected float getTailRotation(final EntityWolf par1EntityWolf, final float par2) {
        return par1EntityWolf.func_70920_v();
    }
    
    protected float func_77044_a(final EntityLivingBase par1EntityLivingBase, final float par2) {
        return this.getTailRotation((EntityWolf)par1EntityLivingBase, par2);
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.preRenderWolf((EntityWolf)par1EntityLivingBase, par2);
    }
    
    protected ResourceLocation getEntityTextures(final EntityWolf par1EntityWolf) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return par1EntityWolf.func_70909_n() ? RenderCMMRWolf.tamedWolfTextures : (par1EntityWolf.func_70919_bu() ? RenderCMMRWolf.anrgyWolfTextures : RenderCMMRWolf.wolfTextures);
        }
        return par1EntityWolf.func_70909_n() ? RenderCMMRWolf.tamedWolfTexturesBl : (par1EntityWolf.func_70919_bu() ? RenderCMMRWolf.anrgyWolfTexturesBl : RenderCMMRWolf.wolfTexturesBl);
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntityWolf)entity);
    }
    
    static {
        wolfTextures = new ResourceLocation("yarrmateys_cutemobmodels:textures/Wolf.png");
        tamedWolfTextures = new ResourceLocation("yarrmateys_cutemobmodels:textures/Wolf_Tamed.png");
        anrgyWolfTextures = new ResourceLocation("yarrmateys_cutemobmodels:textures/Wolf_Angry.png");
        wolfCollarTextures = new ResourceLocation("yarrmateys_cutemobmodels:textures/Wolf_Collar.png");
        wolfTexturesBl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlWolf.png");
        tamedWolfTexturesBl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlWolf_Tamed.png");
        anrgyWolfTexturesBl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlWolf_Angry.png");
        wolfCollarTexturesBl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlWolf_Collar.png");
    }
}
