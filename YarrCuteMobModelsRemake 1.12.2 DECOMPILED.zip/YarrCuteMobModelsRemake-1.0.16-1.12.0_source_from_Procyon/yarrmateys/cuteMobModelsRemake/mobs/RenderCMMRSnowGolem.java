// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.monster.EntitySnowman;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRSnowGolem extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1Bl;
    protected ModelCMMRSnowGolem cuteModel;
    
    public RenderCMMRSnowGolem(final ModelCMMRSnowGolem modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
    }
    
    protected ResourceLocation getEntityTextures(final EntitySnowman par1EntitySnowGolem) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMRSnowGolem.texture1;
        }
        return RenderCMMRSnowGolem.texture1Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntitySnowman)entity);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/SGolem.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSGolem.png");
    }
}
