// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.world.World;
import net.minecraft.entity.passive.EntityWolf;

public class EntityCMMRWolf extends EntityWolf
{
    public EntityCMMRWolf(final World var1) {
        super(var1);
    }
}
