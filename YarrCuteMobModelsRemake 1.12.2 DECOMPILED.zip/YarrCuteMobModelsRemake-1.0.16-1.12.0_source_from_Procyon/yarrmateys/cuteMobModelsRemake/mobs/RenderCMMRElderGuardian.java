// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.client.renderer.OpenGlHelper;
import org.lwjgl.opengl.GL11;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.AxisAlignedBB;
import net.minecraft.entity.EntityLiving;
import net.minecraft.client.renderer.culling.ICamera;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.monster.EntityGuardian;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMRElderGuardianEyes;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRElderGuardian extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture2;
    private static final ResourceLocation texture1Bl;
    private static final ResourceLocation texture2Bl;
    private static final ResourceLocation texture_beam;
    int param1;
    
    public RenderCMMRElderGuardian(final ModelCMMRElderGuardian modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
        this.param1 = ((ModelCMMRElderGuardian)this.field_77045_g).func_178706_a();
        this.func_177094_a((LayerRenderer)new LayerCMMRElderGuardianEyes(this));
    }
    
    protected void updateGuardianScale(final EntityGuardian par1Entity, final float par2) {
        if (YarrCuteMobModelsRemake.GuardianUseAccurateModelSize) {
            final float f1 = 1.0f;
            final float f2 = 1.0f;
            final float f3 = 1.0f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
        else {
            final float f1 = 1.0f;
            final float f2 = 1.0f;
            final float f3 = 1.0f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.updateGuardianScale((EntityGuardian)par1EntityLivingBase, par2);
    }
    
    public boolean shouldRender(final EntityGuardian livingEntity, final ICamera camera, final double camX, final double camY, final double camZ) {
        if (super.func_177071_a((EntityLiving)livingEntity, camera, camX, camY, camZ)) {
            return true;
        }
        if (livingEntity.func_175474_cn()) {
            final EntityLivingBase entitylivingbase = livingEntity.func_175466_co();
            if (entitylivingbase != null) {
                final Vec3d vec3d = this.func_177110_a(entitylivingbase, entitylivingbase.field_70131_O * 0.5, 1.0f);
                final Vec3d vec3d2 = this.func_177110_a((EntityLivingBase)livingEntity, livingEntity.func_70047_e(), 1.0f);
                if (camera.func_78546_a(new AxisAlignedBB(vec3d2.field_72450_a, vec3d2.field_72448_b, vec3d2.field_72449_c, vec3d.field_72450_a, vec3d.field_72448_b, vec3d.field_72449_c))) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private Vec3d func_177110_a(final EntityLivingBase p_177110_1_, final double p_177110_2_, final float p_177110_4_) {
        final double d1 = p_177110_1_.field_70142_S + (p_177110_1_.field_70165_t - p_177110_1_.field_70142_S) * p_177110_4_;
        final double d2 = p_177110_2_ + p_177110_1_.field_70137_T + (p_177110_1_.field_70163_u - p_177110_1_.field_70137_T) * p_177110_4_;
        final double d3 = p_177110_1_.field_70136_U + (p_177110_1_.field_70161_v - p_177110_1_.field_70136_U) * p_177110_4_;
        return new Vec3d(d1, d2, d3);
    }
    
    public void doRender(final EntityGuardian entity, final double x, final double y, final double z, final float entityYaw, final float partialTicks) {
        if (this.param1 != ((ModelCMMRElderGuardian)this.field_77045_g).func_178706_a()) {
            this.param1 = ((ModelCMMRElderGuardian)this.field_77045_g).func_178706_a();
        }
        super.func_76986_a((EntityLiving)entity, x, y, z, entityYaw, partialTicks);
        final EntityLivingBase entitylivingbase = entity.func_175466_co();
        if (entitylivingbase != null) {
            final float f = entity.func_175477_p(partialTicks);
            final Tessellator tessellator = Tessellator.func_178181_a();
            final BufferBuilder worldrenderer = tessellator.func_178180_c();
            this.func_110776_a(RenderCMMRElderGuardian.texture_beam);
            GL11.glTexParameterf(3553, 10242, 10497.0f);
            GL11.glTexParameterf(3553, 10243, 10497.0f);
            GlStateManager.func_179140_f();
            GlStateManager.func_179129_p();
            GlStateManager.func_179084_k();
            GlStateManager.func_179132_a(true);
            final float f2 = 240.0f;
            OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, f2, f2);
            GlStateManager.func_179120_a(770, 1, 1, 0);
            final float f3 = entity.field_70170_p.func_82737_E() + partialTicks;
            final float f4 = f3 * 0.5f % 1.0f;
            final float f5 = entity.func_70047_e();
            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b((float)x, (float)y + f5, (float)z);
            final Vec3d vec3 = this.func_177110_a(entitylivingbase, entitylivingbase.field_70131_O * 0.5, partialTicks);
            final Vec3d vec4 = this.func_177110_a((EntityLivingBase)entity, f5, partialTicks);
            Vec3d vec5 = vec3.func_178788_d(vec4);
            final double d0 = vec5.func_72433_c() + 1.0;
            vec5 = vec5.func_72432_b();
            final float f6 = (float)Math.acos(vec5.field_72448_b);
            final float f7 = (float)Math.atan2(vec5.field_72449_c, vec5.field_72450_a);
            GlStateManager.func_179114_b((1.5707964f + -f7) * 57.295776f, 0.0f, 1.0f, 0.0f);
            GlStateManager.func_179114_b(f6 * 57.295776f, 1.0f, 0.0f, 0.0f);
            final int i = 1;
            final double d2 = f3 * 0.05 * (1.0 - (i & 0x1) * 2.5);
            worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181709_i);
            final float f8 = f * f;
            final int j = 64 + (int)(f8 * 240.0f);
            final int k = 32 + (int)(f8 * 192.0f);
            final int l = 128 - (int)(f8 * 64.0f);
            final double d3 = i * 0.2;
            final double d4 = d3 * 1.41;
            final double d5 = 0.0 + Math.cos(d2 + 2.356194490192345) * d4;
            final double d6 = 0.0 + Math.sin(d2 + 2.356194490192345) * d4;
            final double d7 = 0.0 + Math.cos(d2 + 0.7853981633974483) * d4;
            final double d8 = 0.0 + Math.sin(d2 + 0.7853981633974483) * d4;
            final double d9 = 0.0 + Math.cos(d2 + 3.9269908169872414) * d4;
            final double d10 = 0.0 + Math.sin(d2 + 3.9269908169872414) * d4;
            final double d11 = 0.0 + Math.cos(d2 + 5.497787143782138) * d4;
            final double d12 = 0.0 + Math.sin(d2 + 5.497787143782138) * d4;
            final double d13 = 0.0 + Math.cos(d2 + 3.141592653589793) * d3;
            final double d14 = 0.0 + Math.sin(d2 + 3.141592653589793) * d3;
            final double d15 = 0.0 + Math.cos(d2 + 0.0) * d3;
            final double d16 = 0.0 + Math.sin(d2 + 0.0) * d3;
            final double d17 = 0.0 + Math.cos(d2 + 1.5707963267948966) * d3;
            final double d18 = 0.0 + Math.sin(d2 + 1.5707963267948966) * d3;
            final double d19 = 0.0 + Math.cos(d2 + 4.71238898038469) * d3;
            final double d20 = 0.0 + Math.sin(d2 + 4.71238898038469) * d3;
            final double d21 = 0.0;
            final double d22 = 0.4999;
            final double d23 = -1.0f + f4;
            final double d24 = d0 * (0.5 / d3) + d23;
            worldrenderer.func_181662_b(d13, d0, d14).func_187315_a(0.4999, d24).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d13, 0.0, d14).func_187315_a(0.4999, d23).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d15, 0.0, d16).func_187315_a(0.0, d23).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d15, d0, d16).func_187315_a(0.0, d24).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d17, d0, d18).func_187315_a(0.4999, d24).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d17, 0.0, d18).func_187315_a(0.4999, d23).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d19, 0.0, d20).func_187315_a(0.0, d23).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d19, d0, d20).func_187315_a(0.0, d24).func_181669_b(j, k, l, 255).func_181675_d();
            double d25 = 0.0;
            if (entity.field_70173_aa % 2 == 0) {
                d25 = 0.5;
            }
            worldrenderer.func_181662_b(d5, d0, d6).func_187315_a(0.5, d25 + 0.5).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d7, d0, d8).func_187315_a(1.0, d25 + 0.5).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d11, d0, d12).func_187315_a(1.0, d25).func_181669_b(j, k, l, 255).func_181675_d();
            worldrenderer.func_181662_b(d9, d0, d10).func_187315_a(0.5, d25).func_181669_b(j, k, l, 255).func_181675_d();
            tessellator.func_78381_a();
            GlStateManager.func_179121_F();
        }
    }
    
    public void func_76986_a(final EntityLiving p_76986_1_, final double p_76986_2_, final double p_76986_4_, final double p_76986_6_, final float p_76986_8_, final float p_76986_9_) {
        this.doRender((EntityGuardian)p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
    }
    
    public boolean func_177104_a(final EntityLiving p_177104_1_, final ICamera p_177104_2_, final double p_177104_3_, final double p_177104_5_, final double p_177104_7_) {
        return this.shouldRender((EntityGuardian)p_177104_1_, p_177104_2_, p_177104_3_, p_177104_5_, p_177104_7_);
    }
    
    public void func_76986_a(final EntityLivingBase p_76986_1_, final double p_76986_2_, final double p_76986_4_, final double p_76986_6_, final float p_76986_8_, final float p_76986_9_) {
        this.doRender((EntityGuardian)p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
    }
    
    protected ResourceLocation getEntityTextures(final EntityGuardian par1Entity) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMRElderGuardian.texture2;
        }
        return RenderCMMRElderGuardian.texture2Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntityGuardian)entity);
    }
    
    public void func_76986_a(final Entity p_76986_1_, final double p_76986_2_, final double p_76986_4_, final double p_76986_6_, final float p_76986_8_, final float p_76986_9_) {
        this.doRender((EntityGuardian)p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
    }
    
    public boolean func_177071_a(final Entity p_177071_1_, final ICamera p_177071_2_, final double p_177071_3_, final double p_177071_5_, final double p_177071_7_) {
        return this.shouldRender((EntityGuardian)p_177071_1_, p_177071_2_, p_177071_3_, p_177071_5_, p_177071_7_);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Guardian.png");
        texture2 = new ResourceLocation("yarrmateys_cutemobmodels:textures/GuardianE.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlGuardian.png");
        texture2Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlGuardianE.png");
        texture_beam = new ResourceLocation("textures/entity/guardian_beam.png");
    }
}
