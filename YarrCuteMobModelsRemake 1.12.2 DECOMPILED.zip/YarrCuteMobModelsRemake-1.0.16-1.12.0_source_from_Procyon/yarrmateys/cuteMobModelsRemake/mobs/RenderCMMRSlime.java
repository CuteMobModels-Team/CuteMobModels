// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.monster.EntitySlime;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRSlime extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture2;
    private static final ResourceLocation texture4;
    private static final ResourceLocation texture1Bl;
    private static final ResourceLocation texture2Bl;
    private static final ResourceLocation texture4Bl;
    private ModelCMMRSlime cuteModel;
    
    public RenderCMMRSlime(final ModelCMMRSlime modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
    }
    
    protected void updateSlimeScale(final EntitySlime par1EntitySlime, final float par2) {
        if (YarrCuteMobModelsRemake.SlimeUseAccurateModelSize) {
            final float f1 = 0.25f * par1EntitySlime.func_70809_q();
            final float f2 = 0.25f * par1EntitySlime.func_70809_q();
            final float f3 = 0.25f * par1EntitySlime.func_70809_q();
            this.field_76989_e = 0.25f * (par1EntitySlime.func_70809_q() * 0.5f);
            GlStateManager.func_179152_a(f1, f2, f3);
        }
        else {
            final float f1 = 0.6f + par1EntitySlime.func_70809_q() * 0.1f;
            final float f2 = 0.6f + par1EntitySlime.func_70809_q() * 0.1f;
            final float f3 = 0.6f + par1EntitySlime.func_70809_q() * 0.1f;
            this.field_76989_e = 3.0f * (par1EntitySlime.func_70809_q() * 0.05f);
            GlStateManager.func_179152_a(f1, f2, f3);
        }
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.updateSlimeScale((EntitySlime)par1EntityLivingBase, par2);
    }
    
    protected ResourceLocation getEntityTextures(final EntitySlime par1EntityLiving) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return (par1EntityLiving.func_70809_q() >= 3) ? RenderCMMRSlime.texture4 : ((par1EntityLiving.func_70809_q() == 2) ? RenderCMMRSlime.texture2 : RenderCMMRSlime.texture1);
        }
        return (par1EntityLiving.func_70809_q() >= 3) ? RenderCMMRSlime.texture4Bl : ((par1EntityLiving.func_70809_q() == 2) ? RenderCMMRSlime.texture2Bl : RenderCMMRSlime.texture1Bl);
    }
    
    protected ResourceLocation func_110775_a(final Entity par1Entity) {
        return this.getEntityTextures((EntitySlime)par1Entity);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Slime1.png");
        texture2 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Slime2.png");
        texture4 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Slime4.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSlime1.png");
        texture2Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSlime2.png");
        texture4Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSlime4.png");
    }
}
