// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.passive.EntityMooshroom;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRMooshroom extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1a;
    private static final ResourceLocation texture1Bl;
    private static final ResourceLocation texture1Bla;
    protected ModelCMMRMooshroom cuteModel;
    
    protected void updateMooshroomScale(final EntityMooshroom par1EntityMooshroom, final float par2) {
        float f1;
        if (YarrCuteMobModelsRemake.MooshroomUseAccurateModelSize) {
            if (!YarrCuteMobModelsRemake.humanMobsModels) {
                f1 = 0.7675f;
            }
            else {
                f1 = 0.7075f;
            }
        }
        else {
            f1 = 0.9375f;
        }
        if (par1EntityMooshroom.func_70874_b() < 0) {
            f1 *= 0.5;
            this.field_76989_e = 0.25f;
        }
        else {
            this.field_76989_e = 0.5f;
        }
        GlStateManager.func_179152_a(f1, f1, f1);
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.updateMooshroomScale((EntityMooshroom)par1EntityLivingBase, par2);
    }
    
    public RenderCMMRMooshroom(final ModelCMMRMooshroom modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
    }
    
    protected ResourceLocation getEntityTextures(final EntityMooshroom par1EntityMooshroom) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return (par1EntityMooshroom.func_70874_b() < 0) ? RenderCMMRMooshroom.texture1a : RenderCMMRMooshroom.texture1;
        }
        return (par1EntityMooshroom.func_70874_b() < 0) ? RenderCMMRMooshroom.texture1Bla : RenderCMMRMooshroom.texture1Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntityMooshroom)entity);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Mooshroom.png");
        texture1a = new ResourceLocation("yarrmateys_cutemobmodels:textures/MooshroomK.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlMooshroom.png");
        texture1Bla = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlMooshroomK.png");
    }
}
