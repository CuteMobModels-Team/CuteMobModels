// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.monster.EntityBlaze;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRBlaze extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1Bl;
    
    public RenderCMMRBlaze(final ModelCMMRBlaze model, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)model, nameTagRange);
    }
    
    protected ResourceLocation getEntityTextures(final EntityBlaze par1Entity) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMRBlaze.texture1;
        }
        return RenderCMMRBlaze.texture1Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity par1Entity) {
        return this.getEntityTextures((EntityBlaze)par1Entity);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Blaze.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlBlaze.png");
    }
}
