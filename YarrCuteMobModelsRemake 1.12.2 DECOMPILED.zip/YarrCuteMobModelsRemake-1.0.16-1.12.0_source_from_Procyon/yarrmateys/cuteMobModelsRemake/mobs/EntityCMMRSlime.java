// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.world.World;
import net.minecraft.entity.monster.EntitySlime;

public class EntityCMMRSlime extends EntitySlime
{
    public EntityCMMRSlime(final World var1) {
        super(var1);
    }
}
