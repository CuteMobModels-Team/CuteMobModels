// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.monster.EntityIronGolem;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRIronGolem extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1Bl;
    protected ModelCMMRIronGolem cuteModel;
    
    public RenderCMMRIronGolem(final ModelCMMRIronGolem modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
    }
    
    protected void updateIronGolemScale(final EntityIronGolem par1EntityIronGolem, final float par2) {
        if (YarrCuteMobModelsRemake.IronGolemUseAccurateModelSize) {
            final float f1 = 1.5f;
            final float f2 = 1.55f;
            final float f3 = 1.5f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
        else {
            final float f1 = 1.0f;
            final float f2 = 1.0f;
            final float f3 = 1.0f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.updateIronGolemScale((EntityIronGolem)par1EntityLivingBase, par2);
    }
    
    protected ResourceLocation getEntityTextures(final EntityIronGolem par1EntityIronGolem) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMRIronGolem.texture1;
        }
        return RenderCMMRIronGolem.texture1Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntityIronGolem)entity);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/IGolem.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlIGolem.png");
    }
}
