// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.world.World;
import net.minecraft.entity.passive.EntityMooshroom;

public class EntityCMMRMooshroom extends EntityMooshroom
{
    public EntityCMMRMooshroom(final World var1) {
        super(var1);
    }
}
