// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.world.World;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.entity.monster.EntityZombieVillager;

public class EntityCMMRZombieVillager extends EntityZombieVillager
{
    private static final DataParameter<Integer> VILLAGER_TYPE;
    private static final DataParameter<String> VILLAGER_TYPE_STR;
    
    public EntityCMMRZombieVillager(final World var1) {
        super(var1);
    }
    
    static {
        VILLAGER_TYPE = EntityDataManager.func_187226_a((Class)EntityZombieVillager.class, DataSerializers.field_187192_b);
        VILLAGER_TYPE_STR = EntityDataManager.func_187226_a((Class)EntityZombieVillager.class, DataSerializers.field_187194_d);
    }
}
