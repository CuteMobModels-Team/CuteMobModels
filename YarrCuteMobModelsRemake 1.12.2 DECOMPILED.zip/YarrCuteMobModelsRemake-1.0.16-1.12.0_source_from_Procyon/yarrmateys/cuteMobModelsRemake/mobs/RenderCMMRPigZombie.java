// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.monster.EntityPigZombie;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMRPigZombieHeldItem;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRPigZombie extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1Bl;
    
    public RenderCMMRPigZombie(final ModelCMMRPigZombie modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
        this.func_177094_a((LayerRenderer)new LayerCMMRPigZombieHeldItem((RenderLivingBase)this));
    }
    
    protected void updatePigZombieScale(final EntityPigZombie par1EntityPigZombie, final float par2) {
        if (par1EntityPigZombie.func_70631_g_()) {
            final float f1 = 0.5f;
            final float f2 = 0.5f;
            final float f3 = 0.5f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
        else {
            final float f1 = 1.0f;
            final float f2 = 1.0f;
            final float f3 = 1.0f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.updatePigZombieScale((EntityPigZombie)par1EntityLivingBase, par2);
    }
    
    protected ResourceLocation getEntityTextures(final EntityPigZombie par1EntityPigZombie) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMRPigZombie.texture1;
        }
        return RenderCMMRPigZombie.texture1Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntityPigZombie)entity);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/PZombie.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlPZombie.png");
    }
}
