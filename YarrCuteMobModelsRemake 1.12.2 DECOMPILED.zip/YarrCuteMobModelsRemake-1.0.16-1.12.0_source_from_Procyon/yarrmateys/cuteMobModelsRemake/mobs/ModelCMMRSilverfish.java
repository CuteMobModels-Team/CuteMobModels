// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.client.renderer.GlStateManager;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.util.math.MathHelper;
import net.minecraft.entity.Entity;
import net.minecraft.client.model.ModelRenderer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.model.ModelBase;

@SideOnly(Side.CLIENT)
public class ModelCMMRSilverfish extends ModelBase
{
    ModelRenderer Hat;
    ModelRenderer HTop;
    ModelRenderer Hair;
    ModelRenderer Head;
    ModelRenderer Neck;
    ModelRenderer RArm;
    ModelRenderer LArm;
    ModelRenderer Body;
    ModelRenderer Body2;
    ModelRenderer Skirt;
    ModelRenderer Skirt2;
    ModelRenderer Skirt3;
    ModelRenderer RLeg;
    ModelRenderer LLeg;
    public ModelRenderer bypedHead;
    public ModelRenderer bypedBody;
    public ModelRenderer bypedRightArm;
    public ModelRenderer bypedLeftArm;
    public ModelRenderer bypedRightLeg;
    public ModelRenderer bypedLeftLeg;
    public ModelRenderer bypedHeadwear;
    public ModelRenderer bypedBodyWear;
    public ModelRenderer bypedLeftArmwear;
    public ModelRenderer bypedRightArmwear;
    public ModelRenderer bypedLeftLegwear;
    public ModelRenderer bypedRightLegwear;
    public ModelRenderer bypedCape;
    public int heldItemLeft;
    public int heldItemRight;
    public boolean isOnLadder;
    public boolean onGround;
    public boolean inWater;
    public boolean inWater2;
    public boolean isSneak;
    public boolean aimedBow;
    private int textureWidthbyped;
    private int textureHeightbyped;
    
    public ModelCMMRSilverfish(final float modelSize, final float offset) {
        this.field_78090_t = 64;
        this.field_78089_u = 64;
        (this.Hat = new ModelRenderer((ModelBase)this, 0, 52)).func_78789_a(3.0f, -8.5f, -2.0f, 3, 5, 4);
        this.Hat.func_78793_a(0.0f, 2.0f, 0.0f);
        this.Hat.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Hat.field_78809_i = true;
        this.setRotation(this.Hat, 0.0f, 0.0f, 0.0f);
        (this.HTop = new ModelRenderer((ModelBase)this, 0, 28)).func_78789_a(-3.5f, -8.0f, -3.0f, 7, 1, 6);
        this.HTop.func_78793_a(0.0f, 2.0f, 0.0f);
        this.HTop.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.HTop.field_78809_i = true;
        this.setRotation(this.HTop, 0.0f, 0.0f, 0.0f);
        (this.Hair = new ModelRenderer((ModelBase)this, 0, 13)).func_78789_a(-4.0f, -7.0f, -3.5f, 8, 8, 7);
        this.Hair.func_78793_a(0.0f, 2.0f, 0.0f);
        this.Hair.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Hair.field_78809_i = true;
        this.setRotation(this.Hair, 0.0f, 0.0f, 0.0f);
        (this.Head = new ModelRenderer((ModelBase)this, 0, 0)).func_78789_a(-3.5f, -7.0f, -3.0f, 7, 7, 6);
        this.Head.func_78793_a(0.0f, 2.0f, 0.0f);
        this.Head.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Head.field_78809_i = true;
        this.setRotation(this.Head, 0.0f, 0.0f, 0.0f);
        (this.Neck = new ModelRenderer((ModelBase)this, 20, 35)).func_78789_a(-1.5f, -1.0f, -1.5f, 3, 2, 3);
        this.Neck.func_78793_a(0.0f, 2.0f, 0.0f);
        this.Neck.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Neck.field_78809_i = true;
        this.setRotation(this.Neck, 0.0f, 0.0f, 0.0f);
        (this.RArm = new ModelRenderer((ModelBase)this, 36, 0)).func_78789_a(-2.0f, -1.0f, -1.0f, 2, 9, 2);
        this.RArm.func_78793_a(-3.5f, 4.0f, 0.0f);
        this.RArm.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.RArm.field_78809_i = true;
        this.setRotation(this.RArm, 0.0f, 0.0f, 0.0f);
        (this.LArm = new ModelRenderer((ModelBase)this, 44, 0)).func_78789_a(0.0f, -1.0f, -1.0f, 2, 9, 2);
        this.LArm.func_78793_a(3.5f, 4.0f, 0.0f);
        this.LArm.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.LArm.field_78809_i = true;
        this.setRotation(this.LArm, 0.0f, 0.0f, 0.0f);
        (this.Body = new ModelRenderer((ModelBase)this, 0, 36)).func_78789_a(-3.5f, 1.0f, -1.5f, 7, 5, 3);
        this.Body.func_78793_a(0.0f, 2.0f, 0.0f);
        this.Body.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Body.field_78809_i = true;
        this.setRotation(this.Body, 0.0f, 0.0f, 0.0f);
        (this.Body2 = new ModelRenderer((ModelBase)this, 0, 44)).func_78789_a(-3.0f, 6.0f, -1.5f, 6, 5, 3);
        this.Body2.func_78793_a(0.0f, 2.0f, 0.0f);
        this.Body2.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Body2.field_78809_i = true;
        this.setRotation(this.Body2, 0.0f, 0.0f, 0.0f);
        (this.Skirt2 = new ModelRenderer((ModelBase)this, 42, 36)).func_78789_a(-3.5f, 0.0f, -2.0f, 7, 3, 4);
        this.Skirt2.func_78793_a(0.0f, 11.0f, 0.0f);
        this.Skirt2.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Skirt2.field_78809_i = true;
        this.setRotation(this.Skirt2, 0.0f, 0.0f, 0.0f);
        (this.Skirt = new ModelRenderer((ModelBase)this, 34, 43)).func_78789_a(-4.5f, 0.0f, -3.0f, 9, 3, 6);
        this.Skirt.func_78793_a(0.0f, 14.0f, 0.0f);
        this.Skirt.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Skirt.field_78809_i = true;
        this.setRotation(this.Skirt, 0.0f, 0.0f, 0.0f);
        (this.Skirt3 = new ModelRenderer((ModelBase)this, 26, 52)).func_78789_a(-5.5f, 3.0f, -4.0f, 11, 4, 8);
        this.Skirt3.func_78793_a(0.0f, 14.0f, 0.0f);
        this.Skirt3.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.Skirt3.field_78809_i = true;
        this.setRotation(this.Skirt3, 0.0f, 0.0f, 0.0f);
        (this.RLeg = new ModelRenderer((ModelBase)this, 52, 0)).func_78789_a(-1.5f, 0.0f, -1.5f, 3, 10, 3);
        this.RLeg.func_78793_a(-2.0f, 14.0f, 0.0f);
        this.RLeg.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.RLeg.field_78809_i = true;
        this.setRotation(this.RLeg, 0.0f, 0.0f, 0.0f);
        (this.LLeg = new ModelRenderer((ModelBase)this, 52, 13)).func_78789_a(-1.5f, 0.0f, -1.5f, 3, 10, 3);
        this.LLeg.func_78793_a(2.0f, 14.0f, 0.0f);
        this.LLeg.func_78787_b(this.field_78090_t, this.field_78089_u);
        this.LLeg.field_78809_i = true;
        this.setRotation(this.LLeg, 0.0f, 0.0f, 0.0f);
        this.textureWidthbyped = 64;
        this.textureHeightbyped = 64;
        (this.bypedHead = new ModelRenderer((ModelBase)this, 0, 0)).func_78790_a(-4.0f, -8.0f, -4.0f, 8, 8, 8, modelSize);
        this.bypedHead.func_78793_a(0.0f, 0.0f + offset, 0.0f);
        this.bypedHead.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedBody = new ModelRenderer((ModelBase)this, 16, 16)).func_78790_a(-4.0f, 0.0f, -2.0f, 8, 12, 4, modelSize);
        this.bypedBody.func_78793_a(0.0f, 0.0f + offset, 0.0f);
        this.bypedBody.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedRightArm = new ModelRenderer((ModelBase)this, 40, 16)).func_78790_a(-3.0f, -2.0f, -2.0f, 4, 12, 4, modelSize);
        this.bypedRightArm.func_78793_a(-5.0f, 2.0f + offset, 0.0f);
        this.bypedRightArm.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedLeftArm = new ModelRenderer((ModelBase)this, 32, 48)).func_78790_a(-1.0f, -2.0f, -2.0f, 4, 12, 4, modelSize);
        this.bypedLeftArm.func_78793_a(5.0f, 2.0f + offset, 0.0f);
        this.bypedLeftArm.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedRightLeg = new ModelRenderer((ModelBase)this, 0, 16)).func_78790_a(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize);
        this.bypedRightLeg.func_78793_a(-1.9f, 12.0f + offset, 0.0f);
        this.bypedRightLeg.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedLeftLeg = new ModelRenderer((ModelBase)this, 16, 48)).func_78790_a(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize);
        this.bypedLeftLeg.func_78793_a(1.9f, 12.0f + offset, 0.0f);
        this.bypedLeftLeg.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedHeadwear = new ModelRenderer((ModelBase)this, 32, 0)).func_78790_a(-4.0f, -8.0f, -4.0f, 8, 8, 8, modelSize + 0.5f);
        this.bypedHeadwear.func_78793_a(0.0f, 0.0f + offset, 0.0f);
        this.bypedHeadwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedBodyWear = new ModelRenderer((ModelBase)this, 16, 32)).func_78790_a(-4.0f, 0.0f, -2.0f, 8, 12, 4, modelSize + 0.25f);
        this.bypedBodyWear.func_78793_a(0.0f, 0.0f, 0.0f);
        this.bypedBodyWear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedLeftArmwear = new ModelRenderer((ModelBase)this, 48, 48)).func_78790_a(-1.0f, -2.0f, -2.0f, 4, 12, 4, modelSize + 0.25f);
        this.bypedLeftArmwear.func_78793_a(5.0f, 2.0f, 0.0f);
        this.bypedLeftArmwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedRightArmwear = new ModelRenderer((ModelBase)this, 40, 32)).func_78790_a(-3.0f, -2.0f, -2.0f, 4, 12, 4, modelSize + 0.25f);
        this.bypedRightArmwear.func_78793_a(-5.0f, 2.0f, 10.0f);
        this.bypedRightArmwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedLeftLegwear = new ModelRenderer((ModelBase)this, 0, 48)).func_78790_a(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize + 0.25f);
        this.bypedLeftLegwear.func_78793_a(1.9f, 12.0f, 0.0f);
        this.bypedLeftLegwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
        (this.bypedRightLegwear = new ModelRenderer((ModelBase)this, 0, 32)).func_78790_a(-2.0f, 0.0f, -2.0f, 4, 12, 4, modelSize + 0.25f);
        this.bypedRightLegwear.func_78793_a(-1.9f, 12.0f, 0.0f);
        this.bypedRightLegwear.func_78787_b(this.textureWidthbyped, this.textureHeightbyped);
    }
    
    private void setRotation(final ModelRenderer model, final float x, final float y, final float z) {
        model.field_78795_f = x;
        model.field_78796_g = y;
        model.field_78808_h = z;
    }
    
    public void func_78087_a(final float par1, final float par2, final float par3, final float par4, final float par5, final float par6, final Entity par7Entity) {
        this.Head.field_78796_g = par4 / 57.295776f;
        this.Head.field_78795_f = par5 / 57.295776f;
        this.Hair.field_78796_g = this.Head.field_78796_g;
        this.Hair.field_78795_f = this.Head.field_78795_f;
        this.Hat.field_78796_g = this.Head.field_78796_g;
        this.Hat.field_78795_f = this.Head.field_78795_f;
        this.HTop.field_78796_g = this.Head.field_78796_g;
        this.HTop.field_78795_f = this.Head.field_78795_f;
        this.Neck.field_78796_g = this.Head.field_78796_g / 2.0f;
        this.RLeg.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f) * 0.6f * par2;
        this.LLeg.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f + 3.1415927f) * 0.6f * par2;
        this.RLeg.field_78796_g = 0.0f;
        this.LLeg.field_78796_g = 0.0f;
        this.RArm.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f + 3.1415927f) * 2.0f * par2 * 0.5f;
        this.LArm.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f) * 2.0f * par2 * 0.5f;
        this.Skirt2.field_78795_f = 0.0f;
        this.Skirt2.field_78796_g = 0.0f;
        this.Skirt.field_78795_f = 0.0f;
        this.Skirt.field_78796_g = 0.0f;
        this.Skirt3.field_78795_f = 0.0f;
        this.Skirt3.field_78796_g = 0.0f;
        this.RLeg.field_82908_p = -0.0f;
        this.LLeg.field_82908_p = -0.0f;
        this.Skirt.field_82908_p = 0.0f;
        this.Skirt.field_82907_q = 0.0f;
        this.Skirt3.field_82908_p = this.Skirt.field_82908_p;
        this.Skirt3.field_82907_q = this.Skirt.field_82907_q;
        if ((par7Entity.field_70122_E && !this.isOnLadder) || par7Entity.func_70090_H() || this.field_78093_q) {
            this.RArm.field_78808_h = 0.1f * MathHelper.func_76126_a(par3 * 0.1f) + 0.1f;
            this.LArm.field_78808_h = -0.1f * MathHelper.func_76126_a(par3 * 0.1f) - 0.1f;
            this.RArm.field_78796_g = 0.0f;
            this.LArm.field_78796_g = 0.0f;
        }
        else {
            final float varX = -2.317994f;
            final float varY = 0.617994f;
            this.RArm.field_78795_f = varX;
            this.RArm.field_78796_g = varY;
            this.LArm.field_78795_f = varX;
            this.LArm.field_78796_g = -varY;
        }
        if (this.field_78093_q) {
            final ModelRenderer rArm = this.RArm;
            rArm.field_78795_f -= 0.62831855f;
            final ModelRenderer lArm = this.LArm;
            lArm.field_78795_f -= 0.62831855f;
            this.RLeg.field_78795_f = -1.2566371f;
            this.LLeg.field_78795_f = -1.2566371f;
            this.RLeg.field_78796_g = 0.31415927f;
            this.LLeg.field_78796_g = -0.31415927f;
            this.Skirt2.field_78795_f = 0.0f;
            this.Skirt2.field_78796_g = 0.0f;
            this.Skirt.field_78795_f = this.RLeg.field_78795_f;
            this.Skirt.field_78796_g = 0.0f;
            this.Skirt3.field_78795_f = this.RLeg.field_78795_f;
            this.Skirt3.field_78796_g = 0.0f;
            this.RLeg.field_82908_p = -0.1f;
            this.LLeg.field_82908_p = -0.1f;
            this.Skirt.field_82908_p = -0.03f;
            this.Skirt3.field_82908_p = this.Skirt.field_82908_p;
            this.Skirt.field_82907_q = 0.0f;
            this.Skirt3.field_82907_q = this.Skirt.field_82907_q;
        }
        this.bypedHead.field_78796_g = par4 / 57.295776f;
        this.bypedHead.field_78795_f = par5 / 57.295776f;
        this.bypedRightArm.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f + 3.1415927f) * 2.0f * par2 * 0.5f;
        this.bypedLeftArm.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f) * 2.0f * par2 * 0.5f;
        this.bypedRightArm.field_78808_h = 0.0f;
        this.bypedLeftArm.field_78808_h = 0.0f;
        this.bypedRightLeg.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f) * 1.4f * par2;
        this.bypedLeftLeg.field_78795_f = MathHelper.func_76134_b(par1 * 0.6662f + 3.1415927f) * 1.4f * par2;
        this.bypedRightLeg.field_78796_g = 0.0f;
        this.bypedLeftLeg.field_78796_g = 0.0f;
        if (this.field_78093_q) {
            final ModelRenderer bypedRightArm = this.bypedRightArm;
            bypedRightArm.field_78795_f -= 0.62831855f;
            final ModelRenderer bypedLeftArm = this.bypedLeftArm;
            bypedLeftArm.field_78795_f -= 0.62831855f;
            this.bypedRightLeg.field_78795_f = -1.2566371f;
            this.bypedLeftLeg.field_78795_f = -1.2566371f;
            this.bypedRightLeg.field_78796_g = 0.31415927f;
            this.bypedLeftLeg.field_78796_g = -0.31415927f;
        }
        if (this.heldItemLeft != 0) {
            this.bypedLeftArm.field_78795_f = this.bypedLeftArm.field_78795_f * 0.5f - 0.31415927f * this.heldItemLeft;
        }
        this.bypedRightArm.field_78796_g = 0.0f;
        this.bypedRightArm.field_78808_h = 0.0f;
        switch (this.heldItemRight) {
            case 1: {
                this.bypedRightArm.field_78795_f = this.bypedRightArm.field_78795_f * 0.5f - 0.31415927f * this.heldItemRight;
                break;
            }
            case 3: {
                this.bypedRightArm.field_78795_f = this.bypedRightArm.field_78795_f * 0.5f - 0.31415927f * this.heldItemRight;
                this.bypedRightArm.field_78796_g = -0.5235988f;
                break;
            }
        }
        this.bypedLeftArm.field_78796_g = 0.0f;
        if (this.field_78095_p > -9990.0f) {
            float f = this.field_78095_p;
            this.bypedBody.field_78796_g = MathHelper.func_76126_a(MathHelper.func_76129_c(f) * 3.1415927f * 2.0f) * 0.2f;
            this.bypedRightArm.field_78798_e = MathHelper.func_76126_a(this.bypedBody.field_78796_g) * 5.0f;
            this.bypedRightArm.field_78800_c = -MathHelper.func_76134_b(this.bypedBody.field_78796_g) * 5.0f;
            this.bypedLeftArm.field_78798_e = -MathHelper.func_76126_a(this.bypedBody.field_78796_g) * 5.0f;
            this.bypedLeftArm.field_78800_c = MathHelper.func_76134_b(this.bypedBody.field_78796_g) * 5.0f;
            final ModelRenderer bypedRightArm2 = this.bypedRightArm;
            bypedRightArm2.field_78796_g += this.bypedBody.field_78796_g;
            final ModelRenderer bypedLeftArm2 = this.bypedLeftArm;
            bypedLeftArm2.field_78796_g += this.bypedBody.field_78796_g;
            final ModelRenderer bypedLeftArm3 = this.bypedLeftArm;
            bypedLeftArm3.field_78795_f += this.bypedBody.field_78796_g;
            f = 1.0f - this.field_78095_p;
            f *= f;
            f *= f;
            f = 1.0f - f;
            final float f2 = MathHelper.func_76126_a(f * 3.1415927f);
            final float f3 = MathHelper.func_76126_a(this.field_78095_p * 3.1415927f) * -(this.bypedHead.field_78795_f - 0.7f) * 0.75f;
            this.bypedRightArm.field_78795_f -= (float)(f2 * 1.2 + f3);
            final ModelRenderer bypedRightArm3 = this.bypedRightArm;
            bypedRightArm3.field_78796_g += this.bypedBody.field_78796_g * 2.0f;
            final ModelRenderer bypedRightArm4 = this.bypedRightArm;
            bypedRightArm4.field_78808_h += MathHelper.func_76126_a(this.field_78095_p * 3.1415927f) * -0.4f;
        }
        if (this.isSneak) {
            this.bypedBody.field_78795_f = 0.5f;
            final ModelRenderer bypedRightArm5 = this.bypedRightArm;
            bypedRightArm5.field_78795_f += 0.4f;
            final ModelRenderer bypedLeftArm4 = this.bypedLeftArm;
            bypedLeftArm4.field_78795_f += 0.4f;
            this.bypedRightLeg.field_78798_e = 4.0f;
            this.bypedLeftLeg.field_78798_e = 4.0f;
            this.bypedRightLeg.field_78797_d = 9.0f;
            this.bypedLeftLeg.field_78797_d = 9.0f;
            this.bypedHead.field_78797_d = 1.0f;
        }
        else {
            this.bypedBody.field_78795_f = 0.0f;
            this.bypedRightLeg.field_78798_e = 0.1f;
            this.bypedLeftLeg.field_78798_e = 0.1f;
            this.bypedRightLeg.field_78797_d = 12.0f;
            this.bypedLeftLeg.field_78797_d = 12.0f;
            this.bypedHead.field_78797_d = 0.0f;
        }
        final ModelRenderer bypedRightArm6 = this.bypedRightArm;
        bypedRightArm6.field_78808_h += MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer bypedLeftArm5 = this.bypedLeftArm;
        bypedLeftArm5.field_78808_h -= MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
        final ModelRenderer bypedRightArm7 = this.bypedRightArm;
        bypedRightArm7.field_78795_f += MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        final ModelRenderer bypedLeftArm6 = this.bypedLeftArm;
        bypedLeftArm6.field_78795_f -= MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        if (this.aimedBow) {
            final float f4 = 0.0f;
            final float f5 = 0.0f;
            this.bypedRightArm.field_78808_h = 0.0f;
            this.bypedLeftArm.field_78808_h = 0.0f;
            this.bypedRightArm.field_78796_g = -(0.1f - f4 * 0.6f) + this.bypedHead.field_78796_g;
            this.bypedLeftArm.field_78796_g = 0.1f - f4 * 0.6f + this.bypedHead.field_78796_g + 0.4f;
            this.bypedRightArm.field_78795_f = -1.5707964f + this.bypedHead.field_78795_f;
            this.bypedLeftArm.field_78795_f = -1.5707964f + this.bypedHead.field_78795_f;
            final ModelRenderer bypedRightArm8 = this.bypedRightArm;
            bypedRightArm8.field_78795_f -= f4 * 1.2f - f5 * 0.4f;
            final ModelRenderer bypedLeftArm7 = this.bypedLeftArm;
            bypedLeftArm7.field_78795_f -= f4 * 1.2f - f5 * 0.4f;
            final ModelRenderer bypedRightArm9 = this.bypedRightArm;
            bypedRightArm9.field_78808_h += MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
            final ModelRenderer bypedLeftArm8 = this.bypedLeftArm;
            bypedLeftArm8.field_78808_h -= MathHelper.func_76134_b(par3 * 0.09f) * 0.05f + 0.05f;
            final ModelRenderer bypedRightArm10 = this.bypedRightArm;
            bypedRightArm10.field_78795_f += MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
            final ModelRenderer bypedLeftArm9 = this.bypedLeftArm;
            bypedLeftArm9.field_78795_f -= MathHelper.func_76126_a(par3 * 0.067f) * 0.05f;
        }
        func_178685_a(this.bypedHead, this.bypedHeadwear);
        func_178685_a(this.bypedBody, this.bypedBodyWear);
        func_178685_a(this.bypedRightArm, this.bypedRightArmwear);
        func_178685_a(this.bypedLeftArm, this.bypedLeftArmwear);
        func_178685_a(this.bypedRightLeg, this.bypedRightLegwear);
        func_178685_a(this.bypedLeftLeg, this.bypedLeftLegwear);
    }
    
    public void func_78088_a(final Entity par1Entity, final float par2, final float par3, final float par4, final float par5, final float par6, final float scale) {
        super.func_78088_a(par1Entity, par2, par3, par4, par5, par6, scale);
        this.func_78087_a(par2, par3, par4, par5, par6, scale, par1Entity);
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            this.Hat.func_78785_a(scale);
            this.HTop.func_78785_a(scale);
            this.Hair.func_78785_a(scale);
            this.Head.func_78785_a(scale);
            this.Neck.func_78785_a(scale);
            this.RArm.func_78785_a(scale);
            this.LArm.func_78785_a(scale);
            this.Body.func_78785_a(scale);
            this.Body2.func_78785_a(scale);
            this.Skirt.func_78785_a(scale);
            this.Skirt2.func_78785_a(scale);
            this.Skirt3.func_78785_a(scale);
            this.RLeg.func_78785_a(scale);
            this.LLeg.func_78785_a(scale);
        }
        else if (this.field_78091_s) {
            final float f1 = 1.5f;
            final float f2 = 2.0f;
            GlStateManager.func_179152_a(f1 / f2, f1 / f2, f1 / f2);
            GlStateManager.func_179109_b(0.0f, 8.0f * scale, 0.0f);
            this.bypedHead.func_78785_a(scale);
            this.bypedHeadwear.func_78785_a(scale);
            this.bypedBody.func_78785_a(scale);
            this.bypedRightArm.func_78785_a(scale);
            this.bypedLeftArm.func_78785_a(scale);
            this.bypedRightLeg.func_78785_a(scale);
            this.bypedLeftLeg.func_78785_a(scale);
            this.bypedBodyWear.func_78785_a(scale);
            this.bypedLeftArmwear.func_78785_a(scale);
            this.bypedRightArmwear.func_78785_a(scale);
            this.bypedLeftLegwear.func_78785_a(scale);
            this.bypedRightLegwear.func_78785_a(scale);
        }
        else {
            if (par1Entity.func_70093_af()) {
                GlStateManager.func_179109_b(0.0f, 0.2f, 0.0f);
            }
            this.bypedHead.func_78785_a(scale);
            this.bypedHeadwear.func_78785_a(scale);
            this.bypedBody.func_78785_a(scale);
            this.bypedRightArm.func_78785_a(scale);
            this.bypedLeftArm.func_78785_a(scale);
            this.bypedRightLeg.func_78785_a(scale);
            this.bypedLeftLeg.func_78785_a(scale);
            this.bypedBodyWear.func_78785_a(scale);
            this.bypedLeftArmwear.func_78785_a(scale);
            this.bypedRightArmwear.func_78785_a(scale);
            this.bypedLeftLegwear.func_78785_a(scale);
            this.bypedRightLegwear.func_78785_a(scale);
        }
    }
}
