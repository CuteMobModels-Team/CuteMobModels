// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.world.World;
import net.minecraft.entity.monster.EntityGhast;

public class EntityCMMRGhast extends EntityGhast
{
    public EntityCMMRGhast(final World var1) {
        super(var1);
    }
}
