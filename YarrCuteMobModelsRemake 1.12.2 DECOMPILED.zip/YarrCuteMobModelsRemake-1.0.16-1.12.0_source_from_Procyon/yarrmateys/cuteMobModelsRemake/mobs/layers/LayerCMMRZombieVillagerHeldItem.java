// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs.layers;

import net.minecraft.client.Minecraft;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRZombieVillager;
import net.minecraft.item.ItemStack;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.EnumHandSide;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;

@SideOnly(Side.CLIENT)
public class LayerCMMRZombieVillagerHeldItem implements LayerRenderer
{
    private final RenderLivingBase livingEntityRenderer;
    
    public LayerCMMRZombieVillagerHeldItem(final RenderLivingBase livingEntityRendererIn) {
        this.livingEntityRenderer = livingEntityRendererIn;
    }
    
    public void func_177141_a(final EntityLivingBase entitylivingbaseIn, final float limbSwing, final float limbSwingAmount, final float partialTicks, final float ageInTicks, final float netHeadYaw, final float headPitch, final float scale) {
        final boolean flag = entitylivingbaseIn.func_184591_cq() == EnumHandSide.RIGHT;
        final ItemStack itemstack = flag ? entitylivingbaseIn.func_184592_cb() : entitylivingbaseIn.func_184614_ca();
        final ItemStack itemstack2 = flag ? entitylivingbaseIn.func_184614_ca() : entitylivingbaseIn.func_184592_cb();
        if (itemstack != null || itemstack2 != null) {
            GlStateManager.func_179094_E();
            if (this.livingEntityRenderer.func_177087_b().field_78091_s) {
                final float f = 1.0f;
                GlStateManager.func_179109_b(0.0f, 0.0f, 0.0f);
                GlStateManager.func_179114_b(0.0f, 0.0f, 0.0f, 0.0f);
                GlStateManager.func_179152_a(f, f, f);
            }
            this.renderHeldItem(entitylivingbaseIn, itemstack2, ItemCameraTransforms.TransformType.THIRD_PERSON_RIGHT_HAND, EnumHandSide.RIGHT);
            this.renderHeldItem(entitylivingbaseIn, itemstack, ItemCameraTransforms.TransformType.THIRD_PERSON_LEFT_HAND, EnumHandSide.LEFT);
            GlStateManager.func_179121_F();
        }
    }
    
    private void renderHeldItem(final EntityLivingBase p_188358_1_, final ItemStack p_188358_2_, final ItemCameraTransforms.TransformType p_188358_3_, final EnumHandSide p_188358_4_) {
        if (p_188358_2_ != null) {
            GlStateManager.func_179094_E();
            ((ModelCMMRZombieVillager)this.livingEntityRenderer.func_177087_b()).postRenderArm(0.0625f, p_188358_4_);
            if (p_188358_1_.func_70093_af()) {
                GlStateManager.func_179109_b(0.0f, 0.2f, 0.0f);
            }
            GlStateManager.func_179114_b(-90.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.func_179114_b(180.0f, 0.0f, 1.0f, 0.0f);
            final boolean flag = p_188358_4_ == EnumHandSide.LEFT;
            GlStateManager.func_179109_b(flag ? -0.0625f : 0.0625f, 0.125f, -0.625f);
            Minecraft.func_71410_x().func_175597_ag().func_187462_a(p_188358_1_, p_188358_2_, p_188358_3_, flag);
            GlStateManager.func_179121_F();
        }
    }
    
    public boolean func_177142_b() {
        return false;
    }
}
