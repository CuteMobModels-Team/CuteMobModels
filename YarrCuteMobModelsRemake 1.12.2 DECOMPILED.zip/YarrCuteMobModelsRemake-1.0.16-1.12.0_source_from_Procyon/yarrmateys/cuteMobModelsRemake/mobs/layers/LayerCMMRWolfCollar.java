// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs.layers;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.passive.EntitySheep;
import net.minecraft.item.EnumDyeColor;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.passive.EntityWolf;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRWolf;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;

@SideOnly(Side.CLIENT)
public class LayerCMMRWolfCollar implements LayerRenderer
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1Bl;
    private final RenderCMMRWolf param1;
    
    public LayerCMMRWolfCollar(final RenderCMMRWolf par1) {
        this.param1 = par1;
    }
    
    public void func_177145_a(final EntityWolf p_177145_1_, final float p_177145_2_, final float p_177145_3_, final float p_177145_4_, final float p_177145_5_, final float p_177145_6_, final float p_177145_7_, final float p_177145_8_) {
        if (p_177145_1_.func_70909_n() && !p_177145_1_.func_82150_aj()) {
            if (!YarrCuteMobModelsRemake.humanMobsModels) {
                this.param1.func_110776_a(LayerCMMRWolfCollar.texture1);
            }
            else {
                this.param1.func_110776_a(LayerCMMRWolfCollar.texture1Bl);
            }
            final EnumDyeColor enumdyecolor = EnumDyeColor.func_176764_b(p_177145_1_.func_175546_cu().func_176767_b());
            final float[] afloat = EntitySheep.func_175513_a(enumdyecolor);
            GlStateManager.func_179124_c(afloat[0], afloat[1], afloat[2]);
            this.param1.func_177087_b().func_78088_a((Entity)p_177145_1_, p_177145_2_, p_177145_3_, p_177145_5_, p_177145_6_, p_177145_7_, p_177145_8_);
        }
    }
    
    public boolean func_177142_b() {
        return true;
    }
    
    public void func_177141_a(final EntityLivingBase p_177141_1_, final float p_177141_2_, final float p_177141_3_, final float p_177141_4_, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float p_177141_8_) {
        this.func_177145_a((EntityWolf)p_177141_1_, p_177141_2_, p_177141_3_, p_177141_4_, p_177141_5_, p_177141_6_, p_177141_7_, p_177141_8_);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Wolf_Collar.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlWolf_Collar.png");
    }
}
