// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs.layers;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.monster.EntityCreeper;
import yarrmateys.cuteMobModelsRemake.mobs.ModelCMMRCreeper;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMRCreeper;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;

@SideOnly(Side.CLIENT)
public class LayerCMMRCreeperCharge implements LayerRenderer
{
    private static final ResourceLocation LIGHTNING_TEXTURE;
    private final RenderCMMRCreeper creeperRenderer;
    private final ModelCMMRCreeper creeperModel;
    
    public LayerCMMRCreeperCharge(final RenderCMMRCreeper par1) {
        this.creeperModel = new ModelCMMRCreeper(2.0f, 0.0f);
        this.creeperRenderer = par1;
    }
    
    public void doRenderLayer(final EntityCreeper par1EntityCreeper, final float p_177169_2_, final float p_177169_3_, final float p_177169_4_, final float p_177169_5_, final float p_177169_6_, final float p_177169_7_, final float p_177169_8_) {
        if (par1EntityCreeper.func_70830_n()) {
            GlStateManager.func_179132_a(!par1EntityCreeper.func_82150_aj());
            this.creeperRenderer.func_110776_a(LayerCMMRCreeperCharge.LIGHTNING_TEXTURE);
            GlStateManager.func_179128_n(5890);
            GlStateManager.func_179096_D();
            final float f7 = par1EntityCreeper.field_70173_aa + p_177169_4_;
            GlStateManager.func_179109_b(f7 * 0.01f, f7 * 0.01f, 0.0f);
            GlStateManager.func_179128_n(5888);
            GlStateManager.func_179147_l();
            final float f8 = 0.5f;
            GlStateManager.func_179131_c(f8, f8, f8, 1.0f);
            GlStateManager.func_179140_f();
            GlStateManager.func_179112_b(1, 1);
            this.creeperModel.func_178686_a(this.creeperRenderer.func_177087_b());
            this.creeperModel.func_78088_a((Entity)par1EntityCreeper, p_177169_2_, p_177169_3_, p_177169_5_, p_177169_6_, p_177169_7_, p_177169_8_);
            GlStateManager.func_179128_n(5890);
            GlStateManager.func_179096_D();
            GlStateManager.func_179128_n(5888);
            GlStateManager.func_179145_e();
            GlStateManager.func_179084_k();
        }
    }
    
    public boolean func_177142_b() {
        return false;
    }
    
    public void func_177141_a(final EntityLivingBase p_177141_1_, final float p_177141_2_, final float p_177141_3_, final float p_177141_4_, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float p_177141_8_) {
        this.doRenderLayer((EntityCreeper)p_177141_1_, p_177141_2_, p_177141_3_, p_177141_4_, p_177141_5_, p_177141_6_, p_177141_7_, p_177141_8_);
    }
    
    static {
        LIGHTNING_TEXTURE = new ResourceLocation("textures/entity/creeper/creeper_armor.png");
    }
}
