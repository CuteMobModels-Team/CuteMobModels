// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs.layers;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.BlockRendererDispatcher;
import net.minecraft.block.state.IBlockState;
import net.minecraft.client.renderer.texture.TextureMap;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.Minecraft;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMREnderman;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMREnderman;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;

@SideOnly(Side.CLIENT)
public class LayerCMMREndermanHeldBlockSeparate implements LayerRenderer<EntityCMMREnderman>
{
    private final RenderCMMREnderman endermanRenderer;
    
    public LayerCMMREndermanHeldBlockSeparate(final RenderCMMREnderman renderCMMREnderman) {
        this.endermanRenderer = renderCMMREnderman;
    }
    
    public void doRenderLayer(final EntityCMMREnderman entitylivingbaseIn, final float limbSwing, final float limbSwingAmount, final float partialTicks, final float ageInTicks, final float netHeadYaw, final float headPitch, final float scale) {
        final IBlockState iblockstate = entitylivingbaseIn.func_175489_ck();
        if (iblockstate != null) {
            final BlockRendererDispatcher blockrendererdispatcher = Minecraft.func_71410_x().func_175602_ab();
            GlStateManager.func_179091_B();
            GlStateManager.func_179094_E();
            GlStateManager.func_179109_b(0.0f, 0.6875f, -0.75f);
            GlStateManager.func_179114_b(20.0f, 1.0f, 0.0f, 0.0f);
            GlStateManager.func_179114_b(45.0f, 0.0f, 1.0f, 0.0f);
            GlStateManager.func_179109_b(0.25f, 0.1875f, 0.25f);
            final float f = 0.5f;
            GlStateManager.func_179152_a(-0.5f, -0.5f, 0.5f);
            final int i = entitylivingbaseIn.func_70070_b();
            final int j = i % 65536;
            final int k = i / 65536;
            OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, (float)j, (float)k);
            GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
            this.endermanRenderer.func_110776_a(TextureMap.field_110575_b);
            blockrendererdispatcher.func_175016_a(iblockstate, 1.0f);
            GlStateManager.func_179121_F();
            GlStateManager.func_179101_C();
        }
    }
    
    public boolean func_177142_b() {
        return false;
    }
}
