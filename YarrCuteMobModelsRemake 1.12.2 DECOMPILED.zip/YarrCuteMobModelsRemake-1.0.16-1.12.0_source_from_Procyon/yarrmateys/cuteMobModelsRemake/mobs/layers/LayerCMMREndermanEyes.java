// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs.layers;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.Entity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.OpenGlHelper;
import net.minecraft.client.renderer.GlStateManager;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.monster.EntityEnderman;
import yarrmateys.cuteMobModelsRemake.mobs.RenderCMMREnderman;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;

@SideOnly(Side.CLIENT)
public class LayerCMMREndermanEyes implements LayerRenderer
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1Bl;
    private final RenderCMMREnderman param1;
    
    public LayerCMMREndermanEyes(final RenderCMMREnderman par1) {
        this.param1 = par1;
    }
    
    public void doRenderLayerEX(final EntityEnderman entitylivingbaseIn, final float limbSwing, final float limbSwingAmount, final float partialTicks, final float ageInTicks, final float netHeadYaw, final float headPitch, final float scale) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            this.param1.func_110776_a(LayerCMMREndermanEyes.texture1);
        }
        else {
            this.param1.func_110776_a(LayerCMMREndermanEyes.texture1Bl);
        }
        GlStateManager.func_179147_l();
        GlStateManager.func_179118_c();
        GlStateManager.func_179112_b(1, 1);
        GlStateManager.func_179140_f();
        if (entitylivingbaseIn.func_82150_aj()) {
            GlStateManager.func_179132_a(false);
        }
        else {
            GlStateManager.func_179132_a(true);
        }
        int i = 61680;
        int j = i % 65536;
        int k = i / 65536;
        OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, (float)j, (float)k);
        GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
        Minecraft.func_71410_x().field_71460_t.func_191514_d(true);
        this.param1.func_177087_b().func_78088_a((Entity)entitylivingbaseIn, limbSwing, limbSwingAmount, ageInTicks, netHeadYaw, headPitch, scale);
        Minecraft.func_71410_x().field_71460_t.func_191514_d(false);
        i = entitylivingbaseIn.func_70070_b();
        j = i % 65536;
        k = i / 65536;
        OpenGlHelper.func_77475_a(OpenGlHelper.field_77476_b, (float)j, (float)k);
        this.param1.func_177105_a((EntityLiving)entitylivingbaseIn);
        GlStateManager.func_179084_k();
        GlStateManager.func_179141_d();
    }
    
    public boolean func_177142_b() {
        return false;
    }
    
    public void func_177141_a(final EntityLivingBase p_177141_1_, final float p_177141_2_, final float p_177141_3_, final float p_177141_4_, final float p_177141_5_, final float p_177141_6_, final float p_177141_7_, final float p_177141_8_) {
        this.doRenderLayerEX((EntityEnderman)p_177141_1_, p_177141_2_, p_177141_3_, p_177141_4_, p_177141_5_, p_177141_6_, p_177141_7_, p_177141_8_);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Enderman_eyes.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlEnderman_eyes.png");
    }
}
