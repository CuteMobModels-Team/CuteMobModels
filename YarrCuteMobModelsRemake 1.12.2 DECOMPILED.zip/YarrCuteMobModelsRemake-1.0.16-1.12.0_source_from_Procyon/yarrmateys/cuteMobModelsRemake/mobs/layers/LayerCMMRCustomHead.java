// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs.layers;

import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.client.renderer.block.model.ItemCameraTransforms;
import net.minecraft.item.ItemArmor;
import net.minecraft.util.EnumFacing;
import net.minecraft.client.renderer.tileentity.TileEntitySkullRenderer;
import net.minecraft.nbt.NBTBase;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.tileentity.TileEntitySkull;
import com.mojang.authlib.GameProfile;
import java.util.UUID;
import net.minecraft.util.StringUtils;
import net.minecraft.nbt.NBTUtil;
import net.minecraft.init.Items;
import net.minecraft.entity.monster.EntityZombieVillager;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.Minecraft;
import net.minecraft.inventory.EntityEquipmentSlot;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.model.ModelRenderer;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;

@SideOnly(Side.CLIENT)
public class LayerCMMRCustomHead implements LayerRenderer
{
    private final ModelRenderer modelRenderer;
    
    public LayerCMMRCustomHead(final ModelRenderer par1) {
        this.modelRenderer = par1;
    }
    
    public void func_177141_a(final EntityLivingBase entitylivingbaseIn, final float limbSwing, final float limbSwingAmount, final float partialTicks, final float ageInTicks, final float netHeadYaw, final float headPitch, final float scale) {
        final ItemStack itemstack = entitylivingbaseIn.func_184582_a(EntityEquipmentSlot.HEAD);
        if (itemstack != null && itemstack.func_77973_b() != null) {
            final Item item = itemstack.func_77973_b();
            final Minecraft minecraft = Minecraft.func_71410_x();
            GlStateManager.func_179094_E();
            if (entitylivingbaseIn.func_70093_af()) {
                GlStateManager.func_179109_b(0.0f, 0.2f, 0.0f);
            }
            final boolean flag = entitylivingbaseIn instanceof EntityVillager || entitylivingbaseIn instanceof EntityZombieVillager;
            if (entitylivingbaseIn.func_70631_g_() && !(entitylivingbaseIn instanceof EntityVillager)) {
                final float f = 2.0f;
                final float f2 = 1.4f;
                GlStateManager.func_179109_b(0.0f, 0.5f * scale, 0.0f);
                GlStateManager.func_179152_a(f2 / f, f2 / f, f2 / f);
                GlStateManager.func_179109_b(0.0f, 16.0f * scale, 0.0f);
            }
            this.modelRenderer.func_78794_c(0.0625f);
            GlStateManager.func_179131_c(1.0f, 1.0f, 1.0f, 1.0f);
            if (item == Items.field_151144_bL) {
                final float f3 = 1.1875f;
                GlStateManager.func_179152_a(f3, -f3, -f3);
                if (flag) {
                    GlStateManager.func_179109_b(0.0f, 0.0625f, 0.0f);
                }
                GameProfile gameprofile = null;
                if (itemstack.func_77942_o()) {
                    final NBTTagCompound nbttagcompound = itemstack.func_77978_p();
                    if (nbttagcompound.func_150297_b("SkullOwner", 10)) {
                        gameprofile = NBTUtil.func_152459_a(nbttagcompound.func_74775_l("SkullOwner"));
                    }
                    else if (nbttagcompound.func_150297_b("SkullOwner", 8)) {
                        final String s = nbttagcompound.func_74779_i("SkullOwner");
                        if (!StringUtils.func_151246_b(s)) {
                            gameprofile = TileEntitySkull.func_174884_b(new GameProfile((UUID)null, s));
                            nbttagcompound.func_74782_a("SkullOwner", (NBTBase)NBTUtil.func_180708_a(new NBTTagCompound(), gameprofile));
                        }
                    }
                }
                TileEntitySkullRenderer.field_147536_b.func_188190_a(-0.5f, 0.0f, -0.5f, EnumFacing.UP, 180.0f, itemstack.func_77960_j(), gameprofile, -1, limbSwing);
            }
            else if (!(item instanceof ItemArmor) || ((ItemArmor)item).func_185083_B_() != EntityEquipmentSlot.HEAD) {
                final float f4 = 0.625f;
                GlStateManager.func_179109_b(0.0f, -0.25f, 0.0f);
                GlStateManager.func_179114_b(180.0f, 0.0f, 1.0f, 0.0f);
                GlStateManager.func_179152_a(f4, -f4, -f4);
                if (flag) {
                    GlStateManager.func_179109_b(0.0f, 0.1875f, 0.0f);
                }
                minecraft.func_175597_ag().func_178099_a(entitylivingbaseIn, itemstack, ItemCameraTransforms.TransformType.HEAD);
            }
            GlStateManager.func_179121_F();
        }
    }
    
    public boolean func_177142_b() {
        return true;
    }
}
