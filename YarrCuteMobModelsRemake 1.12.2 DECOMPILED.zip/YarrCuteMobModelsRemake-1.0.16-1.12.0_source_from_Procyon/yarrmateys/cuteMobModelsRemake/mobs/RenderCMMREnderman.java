// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.monster.EntityEnderman;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMREndermanHeldBlock;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMREndermanHeldBlockSeparate;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMREndermanEyes;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import java.util.Random;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMREnderman extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1Bl;
    private ModelCMMREnderman cuteModel;
    private Random rnd;
    
    public RenderCMMREnderman(final ModelCMMREnderman modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
        this.rnd = new Random();
        this.cuteModel = (ModelCMMREnderman)super.field_77045_g;
        this.func_177094_a((LayerRenderer)new LayerCMMREndermanEyes(this));
        if (YarrCuteMobModelsRemake.separateEntities) {
            this.func_177094_a((LayerRenderer)new LayerCMMREndermanHeldBlockSeparate(this));
        }
        else {
            this.func_177094_a((LayerRenderer)new LayerCMMREndermanHeldBlock(this));
        }
    }
    
    protected void updateEndermanScale(final EntityEnderman par1EntityEnderman, final float par2) {
        if (YarrCuteMobModelsRemake.EndermanUseAccurateModelSize) {
            final float f1 = 1.1f;
            final float f2 = 1.5f;
            final float f3 = 1.1f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
        else {
            final float f1 = 1.0f;
            final float f2 = 1.0f;
            final float f3 = 1.0f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.updateEndermanScale((EntityEnderman)par1EntityLivingBase, par2);
    }
    
    protected ResourceLocation getEntityTextures(final EntityEnderman par1EntityEnderman) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMREnderman.texture1;
        }
        return RenderCMMREnderman.texture1Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntityEnderman)entity);
    }
    
    public void doRender(final EntityEnderman entity, double x, final double y, double z, final float entityYaw, final float partialTicks) {
        final IBlockState iblockstate = entity.func_175489_ck();
        this.cuteModel.isCarrying = (iblockstate != null);
        this.cuteModel.isAttacking = entity.func_70823_r();
        if (entity.func_70823_r()) {
            final double d0 = 0.02;
            x += this.rnd.nextGaussian() * d0;
            z += this.rnd.nextGaussian() * d0;
        }
        super.func_76986_a((EntityLiving)entity, x, y, z, entityYaw, partialTicks);
    }
    
    public void func_76986_a(final Entity p_76986_1_, final double p_76986_2_, final double p_76986_4_, final double p_76986_6_, final float p_76986_8_, final float p_76986_9_) {
        this.doRender((EntityEnderman)p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
    }
    
    public void func_76986_a(final EntityLiving p_76986_1_, final double p_76986_2_, final double p_76986_4_, final double p_76986_6_, final float p_76986_8_, final float p_76986_9_) {
        this.doRender((EntityEnderman)p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
    }
    
    public void func_76986_a(final EntityLivingBase p_76986_1_, final double p_76986_2_, final double p_76986_4_, final double p_76986_6_, final float p_76986_8_, final float p_76986_9_) {
        this.doRender((EntityEnderman)p_76986_1_, p_76986_2_, p_76986_4_, p_76986_6_, p_76986_8_, p_76986_9_);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Enderman.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlEnderman.png");
    }
}
