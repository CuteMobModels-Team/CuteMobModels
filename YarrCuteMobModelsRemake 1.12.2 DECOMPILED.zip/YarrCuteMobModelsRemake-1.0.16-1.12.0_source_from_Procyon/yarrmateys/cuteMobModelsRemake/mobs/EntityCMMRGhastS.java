// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.projectile.EntitySmallFireball;
import net.minecraft.entity.projectile.EntityLargeFireball;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.entity.Entity;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.passive.EntityAmbientCreature;
import net.minecraft.entity.passive.EntityWaterMob;
import net.minecraft.entity.ai.EntityAINearestAttackableTarget;
import net.minecraft.entity.EntityAgeable;
import net.minecraft.entity.ai.EntityAIHurtByTarget;
import net.minecraft.entity.ai.EntityAILookIdle;
import net.minecraft.entity.ai.EntityAIWatchClosest;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.ai.EntityAIWander;
import net.minecraft.entity.EntityCreature;
import net.minecraft.entity.ai.EntityAIMoveTowardsRestriction;
import net.minecraft.entity.ai.EntityAIBase;
import net.minecraft.entity.EntityLiving;
import net.minecraft.entity.ai.EntityAISwimming;
import net.minecraft.world.World;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.entity.monster.EntityMob;

public class EntityCMMRGhastS extends EntityMob
{
    private static final DataParameter<Byte> ON_FIRE;
    private float heightOffset;
    private int heightOffsetUpdateTime;
    private double moveSpeed;
    
    public EntityCMMRGhastS(final World var1) {
        super(var1);
        this.heightOffset = 0.5f;
        this.field_70178_ae = true;
        this.field_70728_aV = 10;
        this.field_70138_W = 1.2f;
        this.field_70714_bg.func_75776_a(0, (EntityAIBase)new EntityAISwimming((EntityLiving)this));
        this.field_70714_bg.func_75776_a(4, (EntityAIBase)new AIFireballAttack());
        this.field_70714_bg.func_75776_a(5, (EntityAIBase)new EntityAIMoveTowardsRestriction((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(7, (EntityAIBase)new EntityAIWander((EntityCreature)this, 1.0));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, (Class)EntityPlayer.class, 8.0f));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAIWatchClosest((EntityLiving)this, (Class)EntityLiving.class, 4.0f));
        this.field_70714_bg.func_75776_a(8, (EntityAIBase)new EntityAILookIdle((EntityLiving)this));
        this.field_70715_bh.func_75776_a(1, (EntityAIBase)new EntityAIHurtByTarget((EntityCreature)this, false, new Class[0]));
        this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, (Class)EntityAgeable.class, true));
        this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, (Class)EntityWaterMob.class, true));
        this.field_70715_bh.func_75776_a(2, (EntityAIBase)new EntityAINearestAttackableTarget((EntityCreature)this, (Class)EntityAmbientCreature.class, true));
    }
    
    protected void func_110147_ax() {
        super.func_110147_ax();
        this.func_110148_a(SharedMonsterAttributes.field_111267_a).func_111128_a(20.0);
        this.func_110148_a(SharedMonsterAttributes.field_111264_e).func_111128_a(6.0);
        this.func_110148_a(SharedMonsterAttributes.field_111263_d).func_111128_a(0.23000000417232513);
        this.func_110148_a(SharedMonsterAttributes.field_111265_b).func_111128_a(48.0);
    }
    
    protected void func_70088_a() {
        super.func_70088_a();
        this.field_70180_af.func_187214_a((DataParameter)EntityCMMRGhastS.ON_FIRE, (Object)0);
    }
    
    protected String getLivingSound() {
        return "mob.ghast.moan";
    }
    
    public void func_70636_d() {
        if (!this.field_70122_E && this.field_70181_x < 0.0) {
            this.field_70181_x *= 0.6;
        }
        if (this.field_70170_p.field_72995_K) {
            if (this.field_70146_Z.nextInt(24) != 0 || !this.func_174814_R()) {}
            for (int i = 0; i < 2; ++i) {}
        }
        super.func_70636_d();
    }
    
    protected void func_70619_bc() {
        if (this.func_70026_G()) {}
        --this.heightOffsetUpdateTime;
        if (this.heightOffsetUpdateTime <= 0) {
            this.heightOffsetUpdateTime = 100;
            this.heightOffset = 0.5f + (float)this.field_70146_Z.nextGaussian() * 3.0f;
        }
        final EntityLivingBase entitylivingbase = this.func_70638_az();
        if (entitylivingbase != null && entitylivingbase.field_70163_u + entitylivingbase.func_70047_e() > this.field_70163_u + this.func_70047_e() + this.heightOffset) {
            this.field_70181_x += (0.30000001192092896 - this.field_70181_x) * 0.30000001192092896;
            this.field_70160_al = true;
        }
        super.func_70619_bc();
    }
    
    public void func_180430_e(final float distance, final float damageMultiplier) {
    }
    
    protected Item func_146068_u() {
        return Items.field_151016_H;
    }
    
    public boolean func_70027_ad() {
        return this.func_70845_n();
    }
    
    protected void func_70628_a(final boolean var1, final int var2) {
        for (int var3 = this.field_70146_Z.nextInt(2) + this.field_70146_Z.nextInt(1 + var2), var4 = 0; var4 < var3; ++var4) {
            this.func_145779_a(Items.field_151073_bk, 1);
        }
        for (int var3 = this.field_70146_Z.nextInt(3) + this.field_70146_Z.nextInt(1 + var2), var4 = 0; var4 < var3; ++var4) {
            this.func_145779_a(Items.field_151016_H, 1);
        }
    }
    
    public boolean func_70845_n() {
        return ((byte)this.field_70180_af.func_187225_a((DataParameter)EntityCMMRGhastS.ON_FIRE) & 0x1) != 0x0;
    }
    
    public void setOnFire(final boolean onFire) {
        byte b0 = (byte)this.field_70180_af.func_187225_a((DataParameter)EntityCMMRGhastS.ON_FIRE);
        if (onFire) {
            b0 |= 0x1;
        }
        else {
            b0 &= 0xFFFFFFFE;
        }
        this.field_70180_af.func_187227_b((DataParameter)EntityCMMRGhastS.ON_FIRE, (Object)b0);
    }
    
    protected boolean func_70814_o() {
        return true;
    }
    
    public boolean func_70601_bi() {
        return this.field_70146_Z.nextInt(20) == 0 && super.func_70601_bi() && this.field_70170_p.func_175659_aa().func_151525_a() > 0;
    }
    
    public int func_70641_bl() {
        return 1;
    }
    
    protected Entity findPlayerToAttack() {
        return null;
    }
    
    public float func_70047_e() {
        return this.field_70131_O * 0.92f;
    }
    
    static {
        ON_FIRE = EntityDataManager.func_187226_a((Class)EntityCMMRGhastS.class, DataSerializers.field_187191_a);
    }
    
    class AIFireballAttack extends EntityAIBase
    {
        private EntityCMMRGhastS ghasts;
        private int field_179467_b;
        private int field_179468_c;
        
        public AIFireballAttack() {
            this.ghasts = EntityCMMRGhastS.this;
            this.func_75248_a(3);
        }
        
        public boolean func_75250_a() {
            final EntityLivingBase entitylivingbase = this.ghasts.func_70638_az();
            return entitylivingbase != null && entitylivingbase.func_70089_S();
        }
        
        public void func_75249_e() {
            this.field_179467_b = 0;
        }
        
        public void func_75251_c() {
            this.ghasts.setOnFire(false);
        }
        
        public void func_75246_d() {
            --this.field_179468_c;
            final EntityLivingBase entitylivingbase = this.ghasts.func_70638_az();
            final double d0 = this.ghasts.func_70068_e((Entity)entitylivingbase);
            if (d0 < 4.0) {
                if (this.field_179468_c <= 0) {
                    this.field_179468_c = 20;
                    this.ghasts.func_70652_k((Entity)entitylivingbase);
                }
                this.ghasts.func_70605_aq().func_75642_a(entitylivingbase.field_70165_t, entitylivingbase.field_70163_u, entitylivingbase.field_70161_v, 1.0);
            }
            else if (d0 < 256.0) {
                final double d2 = entitylivingbase.field_70165_t - this.ghasts.field_70165_t;
                final double d3 = entitylivingbase.func_174813_aQ().field_72338_b + entitylivingbase.field_70131_O / 2.0f - (this.ghasts.field_70163_u + this.ghasts.field_70131_O / 2.0f);
                final double d4 = entitylivingbase.field_70161_v - this.ghasts.field_70161_v;
                if (this.field_179468_c <= 0) {
                    ++this.field_179467_b;
                    if (this.field_179467_b == 1) {
                        this.field_179468_c = 60;
                        this.ghasts.setOnFire(true);
                    }
                    else if (this.field_179467_b <= 4) {
                        this.field_179468_c = 6;
                    }
                    else {
                        this.field_179468_c = 100;
                        this.field_179467_b = 0;
                        this.ghasts.setOnFire(false);
                    }
                    if (this.field_179467_b > 1) {
                        final float f = MathHelper.func_76129_c(MathHelper.func_76133_a(d0)) * 0.5f;
                        this.ghasts.field_70170_p.func_180498_a((EntityPlayer)null, 1009, new BlockPos((int)this.ghasts.field_70165_t, (int)this.ghasts.field_70163_u, (int)this.ghasts.field_70161_v), 0);
                        if (YarrCuteMobModelsRemake.GhastSBrutalGhastSister) {
                            for (int i = 0; i < 1; ++i) {
                                final EntityLargeFireball entitylargefireball = new EntityLargeFireball(this.ghasts.field_70170_p, (EntityLivingBase)this.ghasts, d2 + this.ghasts.func_70681_au().nextGaussian() * f, d3, d4 + this.ghasts.func_70681_au().nextGaussian() * f);
                                entitylargefireball.field_70163_u = this.ghasts.field_70163_u + this.ghasts.field_70131_O / 2.0f + 0.5;
                                this.ghasts.field_70170_p.func_72838_d((Entity)entitylargefireball);
                            }
                        }
                        else {
                            for (int i = 0; i < 1; ++i) {
                                final EntitySmallFireball entitysmallfireball = new EntitySmallFireball(this.ghasts.field_70170_p, (EntityLivingBase)this.ghasts, d2 + this.ghasts.func_70681_au().nextGaussian() * f, d3, d4 + this.ghasts.func_70681_au().nextGaussian() * f);
                                entitysmallfireball.field_70163_u = this.ghasts.field_70163_u + this.ghasts.field_70131_O / 2.0f + 0.5;
                                this.ghasts.field_70170_p.func_72838_d((Entity)entitysmallfireball);
                            }
                        }
                    }
                }
                this.ghasts.func_70671_ap().func_75651_a((Entity)entitylivingbase, 10.0f, 10.0f);
            }
            else {
                this.ghasts.func_70661_as().func_75499_g();
                this.ghasts.func_70605_aq().func_75642_a(entitylivingbase.field_70165_t, entitylivingbase.field_70163_u, entitylivingbase.field_70161_v, 1.0);
            }
            super.func_75246_d();
        }
    }
}
