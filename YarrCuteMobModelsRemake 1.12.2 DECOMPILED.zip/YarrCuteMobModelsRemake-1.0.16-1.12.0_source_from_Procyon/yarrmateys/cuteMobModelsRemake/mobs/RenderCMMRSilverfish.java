// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.monster.EntitySilverfish;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRSilverfish extends RenderLiving
{
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture1Bl;
    protected ModelCMMRSilverfish cuteModel;
    
    public RenderCMMRSilverfish(final ModelCMMRSilverfish modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
    }
    
    protected void updateSilverfishScale(final EntitySilverfish par1EntitySilverfish, final float par2) {
        if (YarrCuteMobModelsRemake.SilverfishUseAccurateModelSize) {
            final float f1 = 0.2f;
            final float f2 = 0.2f;
            final float f3 = 0.2f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
        else {
            final float f1 = 0.9f;
            final float f2 = 0.9f;
            final float f3 = 0.9f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.updateSilverfishScale((EntitySilverfish)par1EntityLivingBase, par2);
    }
    
    protected ResourceLocation getEntityTextures(final EntitySilverfish par1EntitySilverfish) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMRSilverfish.texture1;
        }
        return RenderCMMRSilverfish.texture1Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntitySilverfish)entity);
    }
    
    static {
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/SFish.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSFish.png");
    }
}
