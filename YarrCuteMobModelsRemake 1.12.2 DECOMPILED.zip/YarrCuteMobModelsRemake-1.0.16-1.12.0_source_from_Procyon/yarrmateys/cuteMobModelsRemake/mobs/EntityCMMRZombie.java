// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.world.World;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.entity.monster.EntityZombie;

public class EntityCMMRZombie extends EntityZombie
{
    private static final DataParameter<Integer> VILLAGER_TYPE;
    private static final DataParameter<String> VILLAGER_TYPE_STR;
    
    public EntityCMMRZombie(final World var1) {
        super(var1);
    }
    
    public int getProfession() {
        return Math.max((int)this.field_70180_af.func_187225_a((DataParameter)EntityCMMRZombie.VILLAGER_TYPE) % 5, 0);
    }
    
    static {
        VILLAGER_TYPE = EntityDataManager.func_187226_a((Class)EntityZombie.class, DataSerializers.field_187192_b);
        VILLAGER_TYPE_STR = EntityDataManager.func_187226_a((Class)EntityZombie.class, DataSerializers.field_187194_d);
    }
}
