// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMRSkeletonHeldItem;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.entity.monster.EntityWitherSkeleton;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRWitherSkeleton extends RenderLiving<EntityWitherSkeleton>
{
    private static final ResourceLocation SKELETON;
    private static final ResourceLocation WITHER_SKELETON;
    private static final ResourceLocation STRAY_SKELETON;
    private static final ResourceLocation SKELETON_BL;
    private static final ResourceLocation WITHER_SKELETON_BL;
    private static final ResourceLocation STRAY_SKELETON_BL;
    protected ModelCMMRSkeleton ModelCMMRSkeletonMain;
    protected float field_40296_d;
    
    public RenderCMMRWitherSkeleton(final ModelCMMRSkeleton modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
        this.func_177094_a((LayerRenderer)new LayerCMMRSkeletonHeldItem((RenderLivingBase)this));
    }
    
    protected void updateSkeletonScale(final EntityWitherSkeleton par1EntitySkeleton, final float par2) {
        final float f1 = 1.0f;
        final float f2 = 1.25f;
        final float f3 = 1.0f;
        GlStateManager.func_179152_a(f1, f2, f3);
    }
    
    protected void preRenderCallback(final EntityWitherSkeleton entitylivingbaseIn, final float partialTickTime) {
        GlStateManager.func_179152_a(1.2f, 1.2f, 1.2f);
    }
    
    protected ResourceLocation getEntityTexture(final EntityWitherSkeleton entity) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return RenderCMMRWitherSkeleton.WITHER_SKELETON;
        }
        return RenderCMMRWitherSkeleton.WITHER_SKELETON_BL;
    }
    
    static {
        SKELETON = new ResourceLocation("yarrmateys_cutemobmodels:textures/Skeleton.png");
        WITHER_SKELETON = new ResourceLocation("yarrmateys_cutemobmodels:textures/SkeletonW.png");
        STRAY_SKELETON = new ResourceLocation("yarrmateys_cutemobmodels:textures/SkeletonS.png");
        SKELETON_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSkeleton.png");
        WITHER_SKELETON_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSkeletonW.png");
        STRAY_SKELETON_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlSkeletonS.png");
    }
}
