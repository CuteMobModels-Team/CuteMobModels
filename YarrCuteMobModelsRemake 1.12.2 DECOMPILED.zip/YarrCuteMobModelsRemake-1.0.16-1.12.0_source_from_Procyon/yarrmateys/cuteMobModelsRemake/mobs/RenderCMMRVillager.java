// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.passive.EntityVillager;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.entity.layers.LayerCustomHead;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRVillager extends RenderLiving
{
    private static final ResourceLocation VILLAGER_UNUSED;
    private static final ResourceLocation VILLAGER_FARMER;
    private static final ResourceLocation VILLAGER_LIBRARIAN;
    private static final ResourceLocation VILLAGER_PRIEST;
    private static final ResourceLocation VILLAGER_SMITH;
    private static final ResourceLocation VILLAGER_BUTCHER;
    private static final ResourceLocation VILLAGER_UNUSED_BL;
    private static final ResourceLocation VILLAGER_FARMER_BL;
    private static final ResourceLocation VILLAGER_LIBRARIAN_BL;
    private static final ResourceLocation VILLAGER_PRIEST_BL;
    private static final ResourceLocation VILLAGER_SMITH_BL;
    private static final ResourceLocation VILLAGER_BUTCHER_BL;
    private ModelCMMRVillager cuteModel;
    
    public RenderCMMRVillager(final ModelCMMRVillager modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
        this.func_177094_a((LayerRenderer)new LayerCustomHead(this.func_177134_g().villagerHead));
    }
    
    public ModelCMMRVillager func_177134_g() {
        return (ModelCMMRVillager)super.func_177087_b();
    }
    
    protected void preRenderVillager(final EntityVillager par1EntityVillager, final float par2) {
        float f1 = 0.9375f;
        if (par1EntityVillager.func_70874_b() < 0) {
            f1 *= 0.5;
            this.field_76989_e = 0.25f;
        }
        else {
            this.field_76989_e = 0.5f;
        }
        GlStateManager.func_179152_a(f1, f1, f1);
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.preRenderVillager((EntityVillager)par1EntityLivingBase, par2);
    }
    
    protected ResourceLocation getEntityTextures(final EntityVillager entity) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            switch (entity.func_70946_n()) {
                case 0: {
                    return RenderCMMRVillager.VILLAGER_FARMER;
                }
                case 1: {
                    return RenderCMMRVillager.VILLAGER_LIBRARIAN;
                }
                case 2: {
                    return RenderCMMRVillager.VILLAGER_PRIEST;
                }
                case 3: {
                    return RenderCMMRVillager.VILLAGER_SMITH;
                }
                case 4: {
                    return RenderCMMRVillager.VILLAGER_BUTCHER;
                }
                default: {
                    return entity.getProfessionForge().getSkin();
                }
            }
        }
        else {
            switch (entity.func_70946_n()) {
                case 0: {
                    return RenderCMMRVillager.VILLAGER_FARMER_BL;
                }
                case 1: {
                    return RenderCMMRVillager.VILLAGER_LIBRARIAN_BL;
                }
                case 2: {
                    return RenderCMMRVillager.VILLAGER_PRIEST_BL;
                }
                case 3: {
                    return RenderCMMRVillager.VILLAGER_SMITH_BL;
                }
                case 4: {
                    return RenderCMMRVillager.VILLAGER_BUTCHER_BL;
                }
                default: {
                    return entity.getProfessionForge().getSkin();
                }
            }
        }
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTextures((EntityVillager)entity);
    }
    
    static {
        VILLAGER_UNUSED = new ResourceLocation("yarrmateys_cutemobmodels:textures/Vill1.png");
        VILLAGER_FARMER = new ResourceLocation("yarrmateys_cutemobmodels:textures/Vill2.png");
        VILLAGER_LIBRARIAN = new ResourceLocation("yarrmateys_cutemobmodels:textures/Vill3.png");
        VILLAGER_PRIEST = new ResourceLocation("yarrmateys_cutemobmodels:textures/Vill4.png");
        VILLAGER_SMITH = new ResourceLocation("yarrmateys_cutemobmodels:textures/Vill5.png");
        VILLAGER_BUTCHER = new ResourceLocation("yarrmateys_cutemobmodels:textures/Vill6.png");
        VILLAGER_UNUSED_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlVill1.png");
        VILLAGER_FARMER_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlVill2.png");
        VILLAGER_LIBRARIAN_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlVill3.png");
        VILLAGER_PRIEST_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlVill4.png");
        VILLAGER_SMITH_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlVill5.png");
        VILLAGER_BUTCHER_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlVill6.png");
    }
}
