// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.monster.EntityZombie;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import net.minecraft.client.renderer.entity.RenderLivingBase;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMRZombieHeldItem;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRZombie extends RenderLiving
{
    private static final ResourceLocation ZOMBIE_VILLAGER_BLANK;
    private static final ResourceLocation ZOMBIE_VILLAGER_FARMER;
    private static final ResourceLocation ZOMBIE_VILLAGER_LIBRARIAN;
    private static final ResourceLocation ZOMBIE_VILLAGER_PRIEST;
    private static final ResourceLocation ZOMBIE_VILLAGER_SMITH;
    private static final ResourceLocation ZOMBIE_VILLAGER_BUTCHER;
    private static final ResourceLocation ZOMBIE_VILLAGER_BLANK_BL;
    private static final ResourceLocation ZOMBIE_VILLAGER_FARMER_BL;
    private static final ResourceLocation ZOMBIE_VILLAGER_LIBRARIAN_BL;
    private static final ResourceLocation ZOMBIE_VILLAGER_PRIEST_BL;
    private static final ResourceLocation ZOMBIE_VILLAGER_SMITH_BL;
    private static final ResourceLocation ZOMBIE_VILLAGER_BUTCHER_BL;
    private static final ResourceLocation ZOMBIE_TEXTURES;
    private static final ResourceLocation ZOMBIE_TEXTURES_BL;
    private static final ResourceLocation HUSK_TEXTURES;
    private static final ResourceLocation HUSK_TEXTURES_BL;
    protected ModelCMMRZombie cuteModel;
    protected float field_40296_d;
    
    public RenderCMMRZombie(final ModelCMMRZombie modelCMMR, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)modelCMMR, nameTagRange);
        this.func_177094_a((LayerRenderer)new LayerCMMRZombieHeldItem((RenderLivingBase)this));
    }
    
    protected void updateZombieScale(final EntityZombie entity, final float par2) {
        if (entity.func_70631_g_()) {
            final float f1 = 0.5f;
            final float f2 = 0.5f;
            final float f3 = 0.5f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
        else {
            final float f1 = 1.0f;
            final float f2 = 1.0f;
            final float f3 = 1.0f;
            GlStateManager.func_179152_a(f1, f2, f3);
        }
    }
    
    protected void func_77041_b(final EntityLivingBase entity, final float par2) {
        this.updateZombieScale((EntityZombie)entity, par2);
    }
    
    protected ResourceLocation getEntityTexture(final EntityZombie entity) {
        return YarrCuteMobModelsRemake.humanMobsModels ? RenderCMMRZombie.ZOMBIE_TEXTURES_BL : RenderCMMRZombie.ZOMBIE_TEXTURES;
    }
    
    protected ResourceLocation func_110775_a(final Entity entity) {
        return this.getEntityTexture((EntityZombie)entity);
    }
    
    static {
        ZOMBIE_VILLAGER_BLANK = new ResourceLocation("yarrmateys_cutemobmodels:textures/ZombieV1.png");
        ZOMBIE_VILLAGER_FARMER = new ResourceLocation("yarrmateys_cutemobmodels:textures/ZombieV2.png");
        ZOMBIE_VILLAGER_LIBRARIAN = new ResourceLocation("yarrmateys_cutemobmodels:textures/ZombieV3.png");
        ZOMBIE_VILLAGER_PRIEST = new ResourceLocation("yarrmateys_cutemobmodels:textures/ZombieV4.png");
        ZOMBIE_VILLAGER_SMITH = new ResourceLocation("yarrmateys_cutemobmodels:textures/ZombieV5.png");
        ZOMBIE_VILLAGER_BUTCHER = new ResourceLocation("yarrmateys_cutemobmodels:textures/ZombieV6.png");
        ZOMBIE_VILLAGER_BLANK_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlZombieV1.png");
        ZOMBIE_VILLAGER_FARMER_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlZombieV2.png");
        ZOMBIE_VILLAGER_LIBRARIAN_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlZombieV3.png");
        ZOMBIE_VILLAGER_PRIEST_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlZombieV4.png");
        ZOMBIE_VILLAGER_SMITH_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlZombieV5.png");
        ZOMBIE_VILLAGER_BUTCHER_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlZombieV6.png");
        ZOMBIE_TEXTURES = new ResourceLocation("yarrmateys_cutemobmodels:textures/Zombie.png");
        ZOMBIE_TEXTURES_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlZombie.png");
        HUSK_TEXTURES = new ResourceLocation("yarrmateys_cutemobmodels:textures/ZombieHusk.png");
        HUSK_TEXTURES_BL = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlZombieHusk.png");
    }
}
