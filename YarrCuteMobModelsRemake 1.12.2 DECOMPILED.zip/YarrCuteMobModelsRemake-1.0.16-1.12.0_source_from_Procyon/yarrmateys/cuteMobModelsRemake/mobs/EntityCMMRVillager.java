// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.network.datasync.EntityDataManager;
import net.minecraft.network.datasync.DataSerializers;
import net.minecraft.world.World;
import net.minecraft.network.datasync.DataParameter;
import net.minecraft.entity.passive.EntityVillager;

public class EntityCMMRVillager extends EntityVillager
{
    private static final DataParameter<Integer> PROFESSION;
    private static final DataParameter<String> PROFESSION_STR;
    
    public EntityCMMRVillager(final World var1) {
        super(var1);
    }
    
    static {
        PROFESSION = EntityDataManager.func_187226_a((Class)EntityVillager.class, DataSerializers.field_187192_b);
        PROFESSION_STR = EntityDataManager.func_187226_a((Class)EntityVillager.class, DataSerializers.field_187194_d);
    }
}
