// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake.mobs;

import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.YarrCuteMobModelsRemake;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.util.math.MathHelper;
import net.minecraft.entity.monster.EntityCreeper;
import net.minecraft.client.renderer.entity.layers.LayerRenderer;
import yarrmateys.cuteMobModelsRemake.mobs.layers.LayerCMMRCreeperCharge;
import net.minecraft.client.model.ModelBase;
import net.minecraft.client.Minecraft;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.entity.RenderLiving;

@SideOnly(Side.CLIENT)
public class RenderCMMRCreeper extends RenderLiving
{
    private static final ResourceLocation armoredCreeperTextures;
    private static final ResourceLocation texture1;
    private static final ResourceLocation texture2;
    private static final ResourceLocation texture1Bl;
    private static final ResourceLocation texture2Bl;
    public ModelCMMRCreeper cuteModel;
    
    public RenderCMMRCreeper(final ModelCMMRCreeper model, final float nameTagRange) {
        super(Minecraft.func_71410_x().func_175598_ae(), (ModelBase)model, nameTagRange);
        this.func_177094_a((LayerRenderer)new LayerCMMRCreeperCharge(this));
    }
    
    protected void updateCreeperScale(final EntityCreeper par1EntityCreeper, final float par2) {
        float f1 = par1EntityCreeper.func_70831_j(par2);
        final float f2 = 1.0f + MathHelper.func_76126_a(f1 * 100.0f) * f1 * 0.01f;
        if (f1 < 0.0f) {
            f1 = 0.0f;
        }
        if (f1 > 1.0f) {
            f1 = 1.0f;
        }
        f1 *= f1;
        f1 *= f1;
        final float f3 = (1.0f + f1 * 0.4f) * f2;
        final float f4 = (1.0f + f1 * 0.1f) / f2;
        GlStateManager.func_179152_a(f3, f4, f3);
    }
    
    protected int func_180571_a(final EntityCreeper p_180571_1_, final float p_180571_2_, final float p_180571_3_) {
        final float f2 = p_180571_1_.func_70831_j(p_180571_3_);
        if ((int)(f2 * 10.0f) % 2 == 0) {
            return 0;
        }
        int i = (int)(f2 * 0.2f * 255.0f);
        i = MathHelper.func_76125_a(i, 0, 255);
        return i << 24 | 0xFFFFFF;
    }
    
    protected ResourceLocation getEntityTextures(final EntityCreeper par1EntityCreeper) {
        if (!YarrCuteMobModelsRemake.humanMobsModels) {
            return par1EntityCreeper.func_70830_n() ? RenderCMMRCreeper.texture2 : RenderCMMRCreeper.texture1;
        }
        return par1EntityCreeper.func_70830_n() ? RenderCMMRCreeper.texture2Bl : RenderCMMRCreeper.texture1Bl;
    }
    
    protected ResourceLocation func_110775_a(final Entity par1Entity) {
        return this.getEntityTextures((EntityCreeper)par1Entity);
    }
    
    protected int func_77030_a(final EntityLivingBase p_77030_1_, final float p_77030_2_, final float p_77030_3_) {
        return this.func_180571_a((EntityCreeper)p_77030_1_, p_77030_2_, p_77030_3_);
    }
    
    protected void func_77041_b(final EntityLivingBase par1EntityLivingBase, final float par2) {
        this.updateCreeperScale((EntityCreeper)par1EntityLivingBase, par2);
    }
    
    static {
        armoredCreeperTextures = new ResourceLocation("textures/entity/creeper/creeper_armor.png");
        texture1 = new ResourceLocation("yarrmateys_cutemobmodels:textures/Creeper.png");
        texture2 = new ResourceLocation("yarrmateys_cutemobmodels:textures/CreeperP.png");
        texture1Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlCreeper.png");
        texture2Bl = new ResourceLocation("yarrmateys_cutemobmodels:textures/BlCreeperP.png");
    }
}
