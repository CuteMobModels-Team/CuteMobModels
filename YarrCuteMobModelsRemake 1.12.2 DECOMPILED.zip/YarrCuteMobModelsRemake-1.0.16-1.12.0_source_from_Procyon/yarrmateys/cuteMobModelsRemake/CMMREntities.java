// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake;

import net.minecraft.util.ResourceLocation;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRMooshroom;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSnowman;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRIronGolem;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRHusk;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRZombieVillager;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRZombie;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRWolf;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRWitch;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRVillager;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSpider;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSlime;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRStray;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRWitherSkeleton;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSkeleton;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRSilverfish;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRPigZombie;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRMagmaCube;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRGuardian;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRElderGuardian;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRGhast;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMREnderman;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRCreeper;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRCaveSpider;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRBlaze;
import net.minecraftforge.fml.common.registry.EntityRegistry;
import net.minecraft.init.Biomes;
import net.minecraft.world.biome.Biome;
import net.minecraft.entity.EnumCreatureType;
import net.minecraft.entity.Entity;
import yarrmateys.cuteMobModelsRemake.mobs.EntityCMMRGhastS;

public class CMMREntities
{
    public static void preInit() {
        if (YarrCuteMobModelsRemake.enableMod) {
            if (YarrCuteMobModelsRemake.GhastSSpawnGhastSister) {
                registerModEntity((Class<? extends Entity>)EntityCMMRGhastS.class, "GhastS", 0, 40, 1, true, 13158600, 15790320);
                EntityRegistry.addSpawn((Class)EntityCMMRGhastS.class, 50, 1, 4, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76778_j });
            }
            if (YarrCuteMobModelsRemake.separateEntities) {
                registerModEntity((Class<? extends Entity>)EntityCMMRBlaze.class, "CMMBlaze", 1, 40, 1, true, 16167425, 16775294);
                EntityRegistry.addSpawn((Class)EntityCMMRBlaze.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76778_j });
                registerModEntity((Class<? extends Entity>)EntityCMMRCaveSpider.class, "CMMCaveSpider", 2, 40, 1, true, 803406, 11013646);
                registerModEntity((Class<? extends Entity>)EntityCMMRCreeper.class, "CMMCreeper", 3, 40, 1, true, 894731, 0);
                EntityRegistry.addSpawn((Class)EntityCMMRCreeper.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76787_r, Biomes.field_150583_P, Biomes.field_150582_Q, Biomes.field_150577_O, Biomes.field_150584_S, Biomes.field_150579_T, Biomes.field_76769_d, Biomes.field_76786_s, Biomes.field_76770_e, Biomes.field_76767_f, Biomes.field_76775_o, Biomes.field_76774_n, Biomes.field_76782_w, Biomes.field_76792_x, Biomes.field_76767_f, Biomes.field_150589_Z, Biomes.field_150607_aa, Biomes.field_76772_c, Biomes.field_150588_X, Biomes.field_150587_Y, Biomes.field_150576_N, Biomes.field_76780_h, Biomes.field_76768_g, Biomes.field_76784_u });
                registerModEntity((Class<? extends Entity>)EntityCMMREnderman.class, "CMMEnderman", 4, 40, 1, true, 1447446, 0);
                EntityRegistry.addSpawn((Class)EntityCMMREnderman.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76787_r, Biomes.field_150583_P, Biomes.field_150582_Q, Biomes.field_150577_O, Biomes.field_150584_S, Biomes.field_150579_T, Biomes.field_76769_d, Biomes.field_76786_s, Biomes.field_76770_e, Biomes.field_76767_f, Biomes.field_76775_o, Biomes.field_76774_n, Biomes.field_76782_w, Biomes.field_76792_x, Biomes.field_76767_f, Biomes.field_150589_Z, Biomes.field_150607_aa, Biomes.field_76772_c, Biomes.field_150588_X, Biomes.field_150587_Y, Biomes.field_150576_N, Biomes.field_76780_h, Biomes.field_76768_g, Biomes.field_76784_u });
                registerModEntity((Class<? extends Entity>)EntityCMMRGhast.class, "CMMGhast", 5, 40, 1, true, 16382457, 12369084);
                EntityRegistry.addSpawn((Class)EntityCMMRGhast.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76778_j });
                registerModEntity((Class<? extends Entity>)EntityCMMRElderGuardian.class, "CMMElderGuardian", 6, 40, 1, true, 13552826, 7632531);
                registerModEntity((Class<? extends Entity>)EntityCMMRGuardian.class, "CMMGuardian", 7, 40, 1, true, 5931634, 15826224);
                registerModEntity((Class<? extends Entity>)EntityCMMRMagmaCube.class, "CMMLavaSlime", 8, 40, 1, true, 3407872, 16579584);
                EntityRegistry.addSpawn((Class)EntityCMMRMagmaCube.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76778_j });
                registerModEntity((Class<? extends Entity>)EntityCMMRPigZombie.class, "CMMPigZombie", 9, 40, 1, true, 15373203, 5009705);
                EntityRegistry.addSpawn((Class)EntityCMMRPigZombie.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76778_j });
                registerModEntity((Class<? extends Entity>)EntityCMMRSilverfish.class, "CMMSilverfish", 10, 40, 1, true, 7237230, 3158064);
                registerModEntity((Class<? extends Entity>)EntityCMMRSkeleton.class, "CMMSkeleton", 11, 40, 1, true, 12698049, 4802889);
                EntityRegistry.addSpawn((Class)EntityCMMRSkeleton.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76787_r, Biomes.field_150583_P, Biomes.field_150582_Q, Biomes.field_150577_O, Biomes.field_150584_S, Biomes.field_150579_T, Biomes.field_76769_d, Biomes.field_76786_s, Biomes.field_76770_e, Biomes.field_76767_f, Biomes.field_76775_o, Biomes.field_76774_n, Biomes.field_76782_w, Biomes.field_76792_x, Biomes.field_76767_f, Biomes.field_150589_Z, Biomes.field_150607_aa, Biomes.field_76772_c, Biomes.field_150588_X, Biomes.field_150587_Y, Biomes.field_150576_N, Biomes.field_76780_h, Biomes.field_76768_g, Biomes.field_76784_u });
                registerModEntity((Class<? extends Entity>)EntityCMMRWitherSkeleton.class, "CMMWitherSkeleton", 12, 40, 1, true, 1315860, 4672845);
                EntityRegistry.addSpawn((Class)EntityCMMRWitherSkeleton.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76778_j });
                registerModEntity((Class<? extends Entity>)EntityCMMRStray.class, "CMMStray", 13, 40, 1, true, 6387319, 14543594);
                EntityRegistry.addSpawn((Class)EntityCMMRStray.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76787_r, Biomes.field_150583_P, Biomes.field_150582_Q, Biomes.field_150577_O, Biomes.field_150584_S, Biomes.field_150579_T, Biomes.field_76769_d, Biomes.field_76786_s, Biomes.field_76770_e, Biomes.field_76767_f, Biomes.field_76775_o, Biomes.field_76774_n, Biomes.field_76782_w, Biomes.field_76792_x, Biomes.field_76767_f, Biomes.field_150589_Z, Biomes.field_150607_aa, Biomes.field_76772_c, Biomes.field_150588_X, Biomes.field_150587_Y, Biomes.field_150576_N, Biomes.field_76780_h, Biomes.field_76768_g, Biomes.field_76784_u });
                registerModEntity((Class<? extends Entity>)EntityCMMRSlime.class, "CMMSlime", 14, 40, 1, true, 5349438, 8306542);
                EntityRegistry.addSpawn((Class)EntityCMMRSlime.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76780_h, Biomes.field_76768_g });
                registerModEntity((Class<? extends Entity>)EntityCMMRSpider.class, "CMMSpider", 15, 40, 1, true, 3419431, 11013646);
                EntityRegistry.addSpawn((Class)EntityCMMRSpider.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76787_r, Biomes.field_150583_P, Biomes.field_150582_Q, Biomes.field_150577_O, Biomes.field_150584_S, Biomes.field_150579_T, Biomes.field_76769_d, Biomes.field_76786_s, Biomes.field_76770_e, Biomes.field_76767_f, Biomes.field_76775_o, Biomes.field_76774_n, Biomes.field_76782_w, Biomes.field_76792_x, Biomes.field_76767_f, Biomes.field_150589_Z, Biomes.field_150607_aa, Biomes.field_76772_c, Biomes.field_150588_X, Biomes.field_150587_Y, Biomes.field_150576_N, Biomes.field_76780_h, Biomes.field_76768_g, Biomes.field_76784_u });
                registerModEntity((Class<? extends Entity>)EntityCMMRVillager.class, "CMMVillager", 16, 40, 1, true, 5651507, 12422002);
                EntityRegistry.addSpawn((Class)EntityCMMRSpider.class, 50, 1, 1, EnumCreatureType.CREATURE, new Biome[] { Biomes.field_76787_r });
                registerModEntity((Class<? extends Entity>)EntityCMMRWitch.class, "CMMWitch", 17, 40, 1, true, 3407872, 5349438);
                EntityRegistry.addSpawn((Class)EntityCMMRWitch.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76787_r, Biomes.field_150583_P, Biomes.field_150582_Q, Biomes.field_150577_O, Biomes.field_150584_S, Biomes.field_150579_T, Biomes.field_76769_d, Biomes.field_76786_s, Biomes.field_76770_e, Biomes.field_76767_f, Biomes.field_76775_o, Biomes.field_76774_n, Biomes.field_76782_w, Biomes.field_76792_x, Biomes.field_76767_f, Biomes.field_150589_Z, Biomes.field_150607_aa, Biomes.field_76772_c, Biomes.field_150588_X, Biomes.field_150587_Y, Biomes.field_150576_N, Biomes.field_76780_h, Biomes.field_76768_g, Biomes.field_76784_u });
                registerModEntity((Class<? extends Entity>)EntityCMMRWolf.class, "CMMWolf", 18, 40, 1, true, 14144467, 13545366);
                EntityRegistry.addSpawn((Class)EntityCMMRWolf.class, 50, 1, 1, EnumCreatureType.CREATURE, new Biome[] { Biomes.field_76768_g, Biomes.field_150584_S });
                registerModEntity((Class<? extends Entity>)EntityCMMRZombie.class, "CMMZombie", 19, 40, 1, true, 44975, 7969893);
                EntityRegistry.addSpawn((Class)EntityCMMRZombie.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76787_r, Biomes.field_150583_P, Biomes.field_150582_Q, Biomes.field_150577_O, Biomes.field_150584_S, Biomes.field_150579_T, Biomes.field_76769_d, Biomes.field_76786_s, Biomes.field_76770_e, Biomes.field_76767_f, Biomes.field_76775_o, Biomes.field_76774_n, Biomes.field_76782_w, Biomes.field_76792_x, Biomes.field_76767_f, Biomes.field_150589_Z, Biomes.field_150607_aa, Biomes.field_76772_c, Biomes.field_150588_X, Biomes.field_150587_Y, Biomes.field_150576_N, Biomes.field_76780_h, Biomes.field_76768_g, Biomes.field_76784_u });
                registerModEntity((Class<? extends Entity>)EntityCMMRZombieVillager.class, "CMMZombieVillager", 20, 40, 1, true, 5651507, 7969893);
                EntityRegistry.addSpawn((Class)EntityCMMRZombieVillager.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76787_r, Biomes.field_150583_P, Biomes.field_150582_Q, Biomes.field_150577_O, Biomes.field_150584_S, Biomes.field_150579_T, Biomes.field_76769_d, Biomes.field_76786_s, Biomes.field_76770_e, Biomes.field_76767_f, Biomes.field_76775_o, Biomes.field_76774_n, Biomes.field_76782_w, Biomes.field_76792_x, Biomes.field_76767_f, Biomes.field_150589_Z, Biomes.field_150607_aa, Biomes.field_76772_c, Biomes.field_150588_X, Biomes.field_150587_Y, Biomes.field_150576_N, Biomes.field_76780_h, Biomes.field_76768_g, Biomes.field_76784_u });
                registerModEntity((Class<? extends Entity>)EntityCMMRHusk.class, "CMMHusk", 21, 40, 1, true, 7958625, 15125652);
                EntityRegistry.addSpawn((Class)EntityCMMRHusk.class, 50, 1, 1, EnumCreatureType.MONSTER, new Biome[] { Biomes.field_76769_d });
                registerModEntity((Class<? extends Entity>)EntityCMMRIronGolem.class, "CMMVillagerGolem", 22, 40, 1, true, 15654607, 11442063);
                registerModEntity((Class<? extends Entity>)EntityCMMRSnowman.class, "CMMSnowGolem", 23, 40, 1, true, 15197924, 14183460);
                registerModEntity((Class<? extends Entity>)EntityCMMRMooshroom.class, "CMMMushroomCow", 24, 40, 1, true, 10489616, 12040119);
                EntityRegistry.addSpawn((Class)EntityCMMRMooshroom.class, 50, 1, 1, EnumCreatureType.CREATURE, new Biome[] { Biomes.field_76789_p, Biomes.field_76788_q });
            }
        }
    }
    
    public static void init() {
    }
    
    private static void registerModEntity(final Class<? extends Entity> entityClass, final String entityName, final int id, final int trackingRange, final int updateFrequency, final boolean sendsVelocityUpdates, final int eggPrimary, final int eggSecondary) {
        EntityRegistry.registerModEntity(new ResourceLocation("yarrmateys_cutemobmodels", entityName), (Class)entityClass, entityName, id, (Object)YarrCuteMobModelsRemake.instance, trackingRange, updateFrequency, sendsVelocityUpdates, eggPrimary, eggSecondary);
    }
}
