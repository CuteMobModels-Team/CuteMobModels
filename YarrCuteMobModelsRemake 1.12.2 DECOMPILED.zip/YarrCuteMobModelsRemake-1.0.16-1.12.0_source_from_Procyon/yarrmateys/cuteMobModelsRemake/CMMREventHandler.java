// 
// Decompiled by Procyon v0.5.36
// 

package yarrmateys.cuteMobModelsRemake;

import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;

public class CMMREventHandler
{
    @SubscribeEvent
    public void OnEntityJoinWorld(final EntityJoinWorldEvent event) {
        if (!YarrCuteMobModelsRemake.enableMod || !event.getWorld().field_72995_K) {}
    }
}
